gUtils 0.2.0 2016-03-18
-----------------------------------------------------------

* Overhauled gr.findoverlaps to rely solely on GenomicRanges::findOverlaps
* Removed gr.match and gr.in, in favor of using GenomicRanges::%over% and %in%
* Changed grl.in to rely on GenomicRanges::findOverlaps

gUtils 0.1.0 2016-03-18
-----------------------------------------------------------

* Initial stable release to Github

