
#' DNAaseI hypersensitivity sites for hg19A
#'
#' DNAaseI hypersensitivity sites from UCSC Table Browser hg19,
#' subsampled to 10,000 sites
#' @name example_dnase
#' @docType data
#' @keywords data
#' @format \code{GRanges}
NULL

#' RefSeq genes for hg19
#'
#' RefSeq genes with exon count and name
#' @name example_genes
#' @docType data
#' @keywords data
#' @format \code{GRanges}
NULL

#' Fake rearrangement data (set 1)
#'
#' @name grl1
#' @docType data
#' @keywords data
#' @format \code{GRangesList}
NULL

#' Fake rearrangement data (set 2)
#'
#' @name grl2
#' @docType data
#' @keywords data
#' @format \code{GRangesList}
NULL

#' \code{Seqinfo} object for hg19
#'
#' @name si
#' @docType data
#' @keywords data
#' @format \code{Seqinfo}
NULL

#' Output standard human genome seqlengths
#'
#' Outputs a standard seqlengths for human genome +/- "chr".
#' @note A default genome can be set with the environment variable DEFAULT_BSGENOME. This
#' can be the full namespace of the genome  e.g.: \code{DEFAULT_BSGENOME=BSgenome.Hsapiens.UCSC.hg19::Hsapiens} OR  a URL / file path pointing to a chrom.sizes text file (e.g. http://genome.ucsc.edu/goldenpath/help/hg19.chrom.sizes) specifying a genome definition
#' @param genome A \code{BSgenome} or object with a \code{seqlengths} accessor. Default is hg19, but loads with warning unless explicitly provided
#' @param chr Flag for whether to keep "chr". Default FALSE
#' @param include.junk Flag for whether to not trim to only 1-22, X, Y, M. Default FALSE
#' @return Named integer vector with elements corresponding to the genome seqlengths
#' @importFrom utils read.delim
#' @author Marcin Imielinski
#' @export
hg_seqlengths = function(genome = NULL, chr = FALSE, include.junk = FALSE)
{
    sl = NULL
    if (is.null(genome)) {
        if (nchar(dbs <- Sys.getenv("DEFAULT_BSGENOME")) == 0)
        {
            warning('hg_seqlengths: supply genome seqlengths or set default with env variable DEFAULT_BSGENOME (e.g. Sys.setenv(DEFAULT_BSGENOME = "BSgenome.Hsapiens.UCSC.hg19::Hsapiens").  DEFAULT_BSGENOME can also be set to a path or URL of a tab delimited text *.chrom.sizes file')
            return(NULL)
        }
        else
        {
            tmp = suppressWarnings(tryCatch(read.delim(dbs, header = FALSE), error= function(e) NULL))
            if (is.null(tmp))
            {
                genome = tryCatch(eval(parse(text=dbs)), error = function(e) NULL)
                if (is.null(genome))
                    stop(sprintf("Error loading %s as BSGenome library ...\nPlease check DEFAULT_BSGENOME setting and set to either an R library BSGenome object or a valid http URL or filepath pointing to a chrom.sizes tab delimited text file.", dbs))
            }
            else
                sl = structure(tmp[,2], names = as.character(tmp[,1]))
                                        #            warning(paste("using default genome:", dbs))
        }}

    if (is.null(sl))
        sl = seqlengths(genome)

    if (!chr)
        names(sl) = gsub('chr', '', names(sl))

    if (!include.junk)
        sl = sl[nchar(names(sl))<=8]
                                        #    sl = sl[c(paste('chr', 1:22, sep = ''), 'chrX', 'chrY', 'chrM')]
    return(sl)
}

#' HiC data for chr14 from Lieberman-Aiden 2009 (in hg19), subsampled
#' to 10,000 interactions
#'
#' @name grl.hiC
#' @docType data
#' @keywords data
#' @format \code{GRangesList}
NULL

#' Converts \code{GRanges} to \code{data.table}
#'
#' and a field grl.iix which saves the (local) index that that gr was in its corresponding grl item
#' @param x \code{GRanges} to convert
#' @name gr2dt
#' @export
#'
gr2dt = function(x)
{
    ## new approach just directly instantiating data table
    cmd = 'data.frame(';
    if (is(x, 'GRanges'))
    {
        ## as.data.table complains if duplicated row names
        if (any(duplicated(names(x))))
            names(x) <- NULL

        was.gr = TRUE
        f = c('seqnames', 'start', 'end', 'strand', 'width')
        f2 = c('as.character(seqnames', 'c(start', 'c(end', 'as.character(strand', 'as.numeric(width')
        cmd = paste(cmd, paste(f, '=', f2, '(x))', sep = '', collapse = ','), sep = '')
        value.f = names(values(x))
    }
    else
    {
        was.gr = FALSE
        value.f = names(x)
    }

    if (length(value.f)>0)
    {
        if (was.gr)
            cmd = paste(cmd, ',', sep = '')
        class.f = sapply(value.f, function(f) eval(parse(text=sprintf("class(x$'%s')", f))))

        .StringSetListAsList = function(x) ### why do I need to do this, bioconductor peeps??
        {
            tmp1 = as.character(unlist(x))
            tmp2 = rep(1:length(x), S4Vectors::elementNROWS(x))
            return(split(tmp1, tmp2))
        }

        ## take care of annoying S4 / DataFrame / data.frame (wish-they-were-non-)issues
        as.statement = ifelse(grepl('Integer', class.f), 'as.integer',
                       ifelse(grepl('Character', class.f), 'as.character',
                       ifelse(grepl('((StringSet)|(Compressed.*))List', class.f), '.StringSetListAsList',
                       ifelse(grepl('StringSet$', class.f), 'as.character',
                       ifelse(grepl('factor$', class.f), 'as.character',
                       ifelse(grepl('List', class.f), 'as.list',
                       ifelse(grepl('factor', class.f), 'as.character',
                       ifelse(grepl('List', class.f), 'as.list', 'c'))))))))
        cmd = paste(cmd, paste(value.f, '=', as.statement, "(x$'", value.f, "')", sep = '', collapse = ','), sep = '')
    }

    cmd = paste(cmd, ')', sep = '')

    out = tryCatch(data.table::as.data.table(eval(parse(text =cmd))), error = function(e) NULL)
    if (is.null(out))
        out = as.data.table(x)
    return(out)
}

#' Get GRanges corresponding to beginning of range
#'
#' @param x \code{GRanges} object to operate on
#' @param width [default = 1] Specify subranges of greater width including the start of the range.
#' @param force [default = F] Allows returned \code{GRanges} to have ranges outside of its \code{Seqinfo} bounds.
#' @param clip [default = F] Trims returned \code{GRanges} so that it does not extend beyond bounds of the input \code{GRanges}
#' @param ignore.strand If set to \code{FALSE}, will extend '-' strands from the other direction [TRUE].
#' @return \code{GRanges} object of width 1 ranges representing start of each genomic range in the input.
#' @importFrom GenomicRanges GRanges
#' @examples
#' gr.start(example_dnase, width=200)
#' gr.start(example_dnase, width=200, clip=TRUE)
#' @export
gr.start <- function(x, width = 1, force = FALSE, ignore.strand = TRUE, clip = TRUE)
{
    if (length(x)==0)
        return(x)

    width = pmax(width, 1)
    
    if (any(seqlengths(x)==0) | any(is.na(seqlengths(x))))
        warning('Check or fix seqlengths, some are equal 0 or NA, may lead to negative widths')

    .grstart = function(x)
    {
        if (force)
        {
            if (ignore.strand)
            {
                st = as.vector(start(x))
                en = as.vector(start(x))+width-1
            }
            else
            {
                st = ifelse(as.logical(strand(x)=='+'),
                            as.vector(start(x)),
                            as.vector(end(x))-width+1)

                en = ifelse(as.logical(strand(x)=='+'),
                            as.vector(start(x))+width-1,
                            as.vector(end(x))
                            )
            }
        }
        else
        {
            if (ignore.strand)
            {
                st = start(x)
                en = pmin(as.vector(start(x))+width-1, seqlengths(x)[as.character(seqnames(x))], na.rm = TRUE)
            }
            else
            {
                st = ifelse(as.logical(strand(x)=='+'),
                            as.vector(start(x)),
                            pmax(as.vector(end(x))-width+1, 1)
                            )

                en = ifelse(as.logical(strand(x)=='+'),
                            pmin(as.vector(start(x))+width-1, seqlengths(x)[as.character(seqnames(x))], na.rm = TRUE),
                            as.vector(end(x)))
            }
        }

        if (clip)
        {
            en = pmin(en, end(x))
            st = pmax(st, start(x))
        }

        ir = IRanges(st, en)
    }

    ir = tryCatch(.grstart(x), error = function(e) NULL)

    if (is.null(ir))
    {
        warning("one or more ranges are out of bounds on seqlengths, fixing and rerunning")
        x = gr.fix(x)
        ir = .grstart(x)
    }

    out = GRanges(seqnames(x), ir, seqlengths = seqlengths(x), strand = strand(x))


    values(out) = values(x)
    return(out)
}

#' Convert data.table to GRanges
#'
#' Takes as input a data.table which must have the following fields: \code{start}, \code{end}, \code{strand}, \code{seqnames}. Will throw
#' an error if any one of these is not present.
#' All of the remaining fields are added as metadata to the \code{GRanges}.
#' @param dt \code{data.table} to convert to \code{GRanges}
#' @return \code{GRanges} object of \code{length = nrow(dt)}
#' @importFrom data.table data.table
#' @importFrom GenomicRanges GRanges mcols
#' @importFrom IRanges IRanges
#' @param dt data.table to convert
#' @name dt2gr
#' @examples
#' gr <- dt2gr(data.table(start=c(1,2), seqnames=c("X", "1"), end=c(10,20), strand = c('+', '-')))
#' @export
dt2gr <- function(dt, key = NULL, seqlengths = hg_seqlengths(), seqinfo = Seqinfo()) {
  out = tryCatch({
        rr <- IRanges(dt$start, dt$end)
      if (!'strand' %in% colnames(dt))
          dt$strand <- '*'
      sf <- factor(dt$strand, levels=c('+', '-', '*'))
      ff <- factor(dt$seqnames, levels=unique(dt$seqnames))
      out <- GRanges(seqnames=ff, ranges=rr, strand=sf, seqlengths = seqlengths)
      if (inherits(dt, 'data.table'))
          mc <- as.data.frame(dt[, setdiff(colnames(dt), c('start', 'end', 'seqnames', 'strand')), with=FALSE])
      else if (inherits(dt, 'data.frame'))
          mc <- as.data.frame(dt[, setdiff(colnames(dt), c('start', 'end', 'seqnames', 'strand')), drop = FALSE])
      else
          warning("Needs to be data.table or data.frame")
      if (nrow(mc))
        mcols(out) <- mc
      out
  }, error = function(e) NULL)

  if (is.null(out))
      {
          warning('coercing to GRanges via non-standard columns')
          out = seg2gr(dt, seqlengths, seqinfo)
      }
    if ("width" %in% names(values(out)))
      out$width = NULL
  return(out)
}

#' Get the right ends of a \code{GRanges}
#'
#' Alternative to \code{GenomicRanges::flank} that will provide end positions *within* intervals
#'
#' @param x \code{GRanges} object to operate on
#' @param width Specify subranges of greater width including the start of the range. \code{[1]}
#' @param force Allows returned \code{GRanges} to have ranges outside of its \code{Seqinfo} bounds. \code{[FALSE]}
#' @param clip Trims returned \code{GRanges} so that it does not extend beyond bounds of the input \code{GRanges}. \code{[TRUE]}
#' @param ignore.strand If set to \code{FALSE}, will extend '-' strands from the other direction. \code{[TRUE]}
#' @return \code{GRanges} object of width = \code{width} ranges representing end of each genomic range in the input.
#' @examples
#' gr.end(example_dnase, width=200, clip=TRUE)
#' @importFrom GenomeInfoDb seqlengths
#' @importFrom GenomicRanges strand seqnames values<- values
#' @author Marcin Imielinski
#' @export
gr.end = function(x, width = 1, force = FALSE, ignore.strand = TRUE, clip = TRUE)
{
    if (length(x)==0)
        return(x)

    if (any(seqlengths(x)==0) | any(is.na(seqlengths(x))))
        warning('Check or fix seqlengths, some are equal 0 or NA, may lead to negative widths')

    width = pmax(width, 1)

    .grend = function(x)
    {
        if (force)
        {
            if (ignore.strand)
            {
                st = as.vector(end(x))-width+1
                en = as.vector(end(x))
            }
            else
            {
                st = ifelse(as.logical(strand(x)=='+'),
                            as.vector(end(x))-width+1,
                            as.vector(start(x)))

                en = ifelse(as.logical(strand(x)=='+'),
                            as.vector(end(x)),
                            as.vector(start(x))+width-1)
            }
            out = GRanges(seqnames(x), IRanges(st, en), seqlengths = seqlengths(x), strand = strand(x))
        }
        else
        {
            if (ignore.strand)
            {
                st = pmax(as.vector(end(x))-width+1, 1)
                en = as.vector(end(x))
            }
            else
            {
                st = ifelse(as.logical(strand(x)=='+'),
                            pmax(as.vector(end(x))-width+1, 1),
                            as.vector(start(x)))

                en = ifelse(as.logical(strand(x)=='+'),
                            as.vector(end(x)),
                            pmin(as.vector(start(x))+width-1, seqlengths(x)[as.character(seqnames(x))], na.rm = TRUE)
                            )
            }

            out = GRanges(seqnames(x), IRanges(st, en), seqlengths = seqlengths(x), strand = strand(x))
        }

        if (clip)
        {
            en = pmin(en, end(x))
            st = pmax(st, start(x))
        }

        return(IRanges(st, en))
    }

    ir = tryCatch(.grend(x), error = function(e) NULL)

    if (is.null(ir))
    {
        warning("one or more ranges are out of bounds on seqlengths, fixing and rerunning")
        x = gr.fix(x)
        ir = .grend(x)
    }

    out = GRanges(seqnames(x), ir, seqlengths = seqlengths(x), strand = strand(x))

    values(out) = values(x)
    return(out)
}

#' Get the midpoints of \code{GRanges} ranges
#'
#' @param x \code{GRanges} object to operate on
#' @return \code{GRanges} of the midpoint, calculated from \code{floor(width(x)/2)}
#' @export
#' @importFrom GenomicRanges start<- end<- start end
#' @examples
#' gr.mid(GRanges(1, IRanges(1000,2000), seqinfo=Seqinfo("1", 2000)))
gr.mid = function(x)
{
    start(x) = end(x) = rowMeans(cbind(start(x), end(x)))
    return(x)
}

#' Generate random \code{GRanges} on genome
#'
#' Randomly generates non-overlapping \code{GRanges} with supplied widths on supplied genome.
#' Seed can be supplied with \code{set.seed}
#'
#' @param w Vector of widths (length of \code{w} determines length of output)
#' @param genome Genome which can be a \code{GRanges}, \code{GRangesList}, or \code{Seqinfo} object. Default is "hg19" from the \code{BSGenome} package.
#' @return \code{GRanges} with random intervals on the specifed "chromosomes"
#' @note This function is currently quite slow, needs optimization
#' @importFrom GenomeInfoDb seqinfo seqnames<-
#' @importFrom GenomicRanges gaps ranges ranges<-
#' @examples
#' ## Generate 5 non-overlapping regions of width 10 on hg19
#' gr.rand(rep(10,5), BSgenome.Hsapiens.UCSC.hg19::Hsapiens)
#' @author Marcin Imielinski
#' @export
gr.rand = function(w, genome)
{

    if (!is(genome, 'Seqinfo'))
        genome = seqinfo(genome)

    sl = seqlengths(genome);
    available = si2gr(genome);

    out = GRanges(rep(names(sl)[1], length(w)), IRanges(rep(1, length(w)), width = 1), seqlengths = seqlengths(genome));
    for (i in 1:length(w))
    {
        if (i == 1)
            available = si2gr(genome)
        else
        {
            available = gaps(out[1:(i-1)])
            available = available[strand(available)=='*']
        }

        available = available[width(available)>w[i]]

        if (length(available)>0)
        {
            end(available) = end(available)-w[i]
            starts = c(1, cumsum(as.numeric(width(available))+1))
            rstart = ceiling(stats::runif(1)*starts[length(starts)])-starts
            rind = max(which(rstart>0))
            new.chr = seqnames(available[rind])
            new.ir = IRanges(rstart[rind]+start(available[rind])-1, width = w[i])

            ## FIX: this is the slowest part
            seqnames(out)[i] = new.chr;
            ranges(out)[i] = new.ir;
        }
        else
            stop('Allocation failed.  Supplied widths are likely too large')
    }

    return(out)
}


#' Trims pile of \code{GRanges} relative to the specified <local> coordinates of each range
#'
#' Example: \code{GRanges} with genomic coordinates 1:1,000,000-1,001,000 can get the first 20 and last 50 bases trimmed off with
#' \code{start = 20, end = 950}.
#' if end is larger than the width of the corresponding gr, then the corresponding output will only have \code{end(gr)} as its coordinate.
#'
#' This is a role not currently provided by the standard \code{GenomicRanges} functions
#' (e.g. \code{shift}, \code{reduce}, \code{restrict}, \code{shift}, \code{resize}, \code{flank})
#' @param gr \code{GRanges} to trim
#' @param starts Number of bases to trim off of the front\code{[1]}
#' @param ends Number of bases to trim off of the back\code{[1]}
#' @examples
#' ## trim the first 20 and last 50 bases
#' gr.trim(GRanges(1, IRanges(1e6, width=1000)), starts=20, ends=950)
#' ## return value: GRanges on 1:1,000,019-1,000,949
#' @export
gr.trim = function(gr, starts=1, ends=1)

    ## note that I deleted ignore.strand and fromEnd options
{
    starts = cbind(1:length(gr), starts)[, 2]
    ends = cbind(1:length(gr), ends)[, 2]

    ##if (!ignore.strand)
    ##    {
    ##    ix = as.logical(strand(gr)=='-')
    ##    if (any(ix))
    ##  {
    ##if (fromEnd)
    ##    {
    ##    tmp = starts[ix]
    ##    starts[ix] = ends[ix]
    ##    ends[ix] = tmp-1
    ##}
    ##else
    ##    {
    ##          starts[ix] = width(gr)[ix]-starts[ix]+1
    ##          ends[ix] = width(gr)[ix]-ends[ix]+1
    ##}
    ##    }
    ##}

    ##  if (fromEnd) {
    ##    en = pmax(starts, end(gr)-ends);
    ##} else {
    ends = pmax(starts, ends);
    ends = pmin(ends, width(gr));
    en = start(gr) + ends - 1;
    ##}

    st = start(gr)+starts-1;
    st = pmin(st, en);

    out = GRanges(seqnames(gr), IRanges(st, en),
                  seqlengths = seqlengths(gr), strand = strand(gr))
    values(out) = values(gr)
    return(out)
}

#' Randomly sample \code{GRanges} intervals within territory
#'
#' Samples \code{k} intervals of length "len" from a pile of \code{GRanges}.
#' \itemize{
#' \item If k is a scalar then will (uniformly) select k intervals from the summed territory of \code{GRanges}
#' \item If k is a vector of length(gr) then will uniformly select k intervals from each.
#' }
#' @param gr \code{GRanges} object defining the territory to sample from
#' @param k Number of ranges to sample
#' @param wid Length of the \code{GRanges} element to produce [100]
#' @param replace If TRUE, will bootstrap, otherwise will sample without replacement. [TRUE]
#' @return GRanges of max length sum(k) [if k is vector) or k*length(gr) (if k is scalar) with labels indicating the originating range.
#'
#' ## sample 5 \code{GRanges} of length 10 each from territory of RefSeq genes
#' gr.sample(reduce(example_genes), k=5, wid=10)
#' @note This is different from \code{GenomicRanges::sample} function, which just samples from a pile of \code{GRanges}
#' @author Marcin Imielinski
#' @export
gr.sample = function(gr, k, wid = 100, replace = TRUE)
{
    if (!inherits(gr, 'GRanges'))
        gr = si2gr(gr)

    if (length(k)==1)
    {
        gr$ix.og = 1:length(gr)
        gr = gr[width(gr)>=wid]
        if (length(gr)==0)
            stop('Input territory has zero regions of sufficient width')
        gr.f = as.data.table(gr.flatten(gr.trim(gr, starts = 1, ends = width(gr)-wid), gap = 0))
        terr = sum(gr.f$end-gr.f$start + 1)
        st = gr.f$start;

        gr.f$ix = 1:nrow(gr.f)


        if (!replace)
        {
            if (!is.na(k))
                s = sort(wid*sample(floor(terr/wid), k, replace = FALSE))
            else
                s = sort(seq(1, terr, wid))
        }
        else
            s = sort(terr*stats::runif(k))

                                        # map back to original gr's
                                        #      si = sapply(s, function(x) {i = 1; while (st[i]<x & i<=length(st)) {i = i+1}; return(i)})
        si = rep(NA, length(s))
        ## concatenate input and random locations
        gr.r = data.table(start = s, end = s+wid-1, ix = as.numeric(NA))
        tmp = rbind(gr.f,  gr.r, fill = TRUE)[order(start), ]

        ## match random events to their last "ix"
        ## find all non NA to NA transitions
        ## and tag all NA runs with the same number
        tmp[, transition := is.na(c(NA, ix[-length(ix)])) != is.na(ix) & is.na(ix)]
        tmp[, nacluster := ifelse(is.na(ix), cumsum(transition), 0)]
        tmp[, clusterlength := length(start), by = nacluster]
        tmp[, ix.new := ifelse(transition, c(NA, ix[-length(ix)]), ix)]
        tmp[, ix.new := ix.new[1], by = nacluster]

        ## now lift up random ranges to their original coordinates
        tmp[is.na(ix), ":="(seqnames = as.character(seqnames(gr)[ix.new]),
                            pos1 = start + start(gr)[ix.new]-gr.f$start[ix.new],
                            pos2 = end + start(gr)[ix.new]-gr.f$start[ix.new])]

        tmp = tmp[is.na(ix), ]

        out = GRanges(tmp$seqnames, IRanges(tmp$pos1, tmp$pos2), strand = '*', seqlengths = seqlengths(gr))
        out$query.id = gr.f$ix.og[tmp$ix.new]
        return(out)
    }
    else
    {
        gr.df = data.frame(chr = as.character(seqnames(gr)), start = start(gr), end = end(gr))
        gr.df$k = k;
        gr.df$length = wid
        gr.df$replace = replace
        tmp = lapply(1:length(gr), function(i)
        {
            if (!gr.df$replace[i])
            {
                if (!is.na(k[i]))
                {
                    w = floor(width(gr)[i]/wid)
                    k[i] = min(k[i], w)
                    if (k[i]>0) {
                        s = wid*sample(w, k[i], replace = FALSE) + gr.df$start[i]
                    } else {
                        warning("gr.sample: trying to sample range of length > width of supplied GRanges element. Returning NULL for this element.")
                        return(NULL)
                    }
                }
                else
                    s = seq(gr.df$start[i], gr.df$end[i], wid)
            }
            else
                s = (gr.df$end[i]-gr.df$start[i]-gr.df$wid[i])*stats::runif(k[i])+gr.df$start[i]

            return(data.frame(chr = gr.df$chr[i], start=s, end =s+wid-1, strand = as.character(strand(gr)[i]), query.id = i))
        })

        ## add check that not all widths are zero
        if (all(sapply(tmp, is.null)))
            stop("gr.sample: Could not sample any ranges. Check that width of input is greater than request width of output")

        return(gr.fix(seg2gr(do.call('rbind', tmp)), gr))
    }
}

#' Create \code{GRanges} from \code{Seqinfo} or \code{BSgenome}
#'
#' Creates a genomic ranges from seqinfo object
#' ie a pile of ranges spanning the genome
#' @param si \code{Seqinfo} object or a \code{BSgenome} genome
#' @param strip.empty Don't know. \code{[FALSE]}
#' @return \code{GRanges} representing the range of the input genome
#' @examples
#' si2gr(BSgenome.Hsapiens.UCSC.hg19::Hsapiens)
#' @export
si2gr <- function(si, strip.empty = FALSE)
{
    if (is(si, "BSgenome"))
        si <- Seqinfo(names(seqlengths(si)), seqlengths(si))
    if (is(si, 'vector')) ## treat si as seqlengths if vector
        si = Seqinfo(seqlengths = si, seqnames = names(si))
    else if (!is(si, 'Seqinfo'))
        si = seqinfo(si)

    sl = seqlengths(si)
    sn = seqnames(si);
    sl[is.na(sl)] = 0;

    if (strip.empty)
    {
        sn = sn[sl!=0];
        sl = sl[sl!=0];
    }

    sigr = GRanges(sn, IRanges(rep(1, length(sl)), width = sl), seqlengths = seqlengths(si), strand = rep('+', length(sl)))
    names(sigr) = sn;

    return(sigr)
}

#' Concatenate \code{GRanges}, robust to different \code{mcols}
#'
#' Concatenates \code{GRanges} objects, taking the union of their features if they have non-overlapping features
#' @param x First \code{GRanges}
#' @param ... additional \code{GRanges}
#' @note Does not fill in the \code{Seqinfo} for the output \code{GRanges}
#' @return Concatenated \code{GRanges}
#' grbind(example_genes, example_dnase)
#' @export
grbind = function(x, ...)
{
    if (missing('x'))
        grs = list(...)
    else if (class(x) != 'list')
        grs <- c(list(x), list(...))
    else
        grs <- c(x, list(...))

    force.rrbind = FALSE
                                        # if ('force.rrbind' %in% names(grs))
                                        #   {
                                        #     if (is.logical(grs[['force.rrbind']]))
                                        #       force.rrbind = grs[['force.rrbind']]
                                        #     grs = grs[-match('force.rrbind', names(grs))]
                                        #   }

                                        #grs = list(...);  # gets list of gr's
    keep = sapply(grs, length)>0 & sapply(grs, function(x) inherits(x, 'GRanges'))
    grs = grs[keep]

    if (length(grs)==0)
        return(NULL)

    if (length(grs)==1)
        return(grs[[1]])

    vals = lapply(grs, function(x) values(x))

    ## DataFrame from IRanges package can hold XStringSets. Convert first

    isDataFrame <- sapply(vals, class) == 'DataFrame'
    if (any(isDataFrame))
    {
        tmp = tryCatch(lapply(vals[isDataFrame], gr2dt), error = function(e) NULL) ## sometimes works, sometimes doesn't
        if (is.null(tmp))
            tmp = lapply(vals[isDataFrame, as.data.frame])

        vals[isDataFrame] = tmp
    }

                                        #      if (any(sapply(vals[isDataFrame][[1]], function(y) inherits(y, 'XStringSet'))))
                                        #        stop('grbind: DataFrame from IRanges contains XStringSet objects. Convert to character, then grbind, then convert back')
### TOFIX: get this to work with XStringSet
                                        #   vals <- lapply(vals, function(x) {
                                        #     isXStringSet <- sapply(x, function(y) inherits(y, 'XStringSet'))
                                        #     x[,isXStringSet] <- DataFrame(sapply(x[,isXStringSet], as.character))
                                        #     return(x)
                                        #   })

### FIXING seqlengths when not exactly matching
    sls = lapply(grs, seqlengths)
    names(sls) = NULL
    levs = unique(names(unlist(sls)))
    sl.new = structure(rep(0, length(levs)), names = levs)
    for (sl in sls)
        sl.new[names(sl)] = pmax(sl.new[names(sl)], sl, na.rm = TRUE)

    bare.grs = lapply(grs, function(x) gr.fix(x[,c()], sl.new))

    ##out = tryCatch(do.call('c', bare.grs), error = function(e) NULL) ## this is annoyingly not working
    out <- dt2gr(rbindlist(lapply(bare.grs, gr2dt)))

                                        # if (is.null(out) | is.list(out)) ## something failed with concatenation, likely some weird ghost with concatenating GRanges with 'c', below is a temp fix
                                        #     {
                                        #         getsridofghostsomehow =  c(bare.grs[[1]], bare.grs[[2]])
                                        #         out = tryCatch(do.call('c', bare.grs), error = function(e) NULL)
                                        #
                                        #         if (is.null(out) | is.list(out)) ## now we are really reaching
                                        #             out = seg2gr(do.call('rrbind', lapply(bare.grs, as.data.frame)), seqlengths = sl.new)[, c()]
                                        #     }

                                        # hack to deal with empty value columns
    ix <- (sapply(vals, ncol)==0)
    if (any(ix))
        vals[ix] = lapply(which(ix), function(x) data.frame(col.4214124124124 = rep(NA, length(grs[[x]]))))

    if (!force.rrbind)
        tmp = tryCatch(do.call('rrbind', vals), error = function(e) NULL)
    else
        tmp = NULL

                                        #if (is.null(tmp) | force.rrbind) ## sometimes rrbind2 gets picky because of type checking (rbindlist) .. so just run rrbind then
                                        #   values(out) = do.call('rrbind', vals)
                                        # else
    values(out) = tmp

    if (any(ix))
        out$col.4214124124124 = NULL
    return(out)
}

#' Concatenate \code{GRangesList} objects.
#'
#' Concatenates \code{GRangesList} objects taking the union of their \code{mcols} features if they have non-overlapping features
#' @param ... Any number of \code{GRangesList} to concatenate together
#' @return Concatenated \code{GRangesList} with NA filled in for \code{mcols} fields that are non-overlapping. Note that the
#' elements are re-named with sequential numbers
#' @examples
#' ## Concatenate
#' grl.hiC2 <- grl.hiC[1:20]
#' mcols(grl.hiC2)$test = 1
#' grlbind(grl.hiC2, grl.hiC[1:30])
#' @export
#' @author Marcin Imielinski
#' @importFrom GenomicRanges mcols<- mcols split
grlbind = function(...)
{
    ## TODO: make this work for when underlying grs do not have matching features
    ## currently will loose gr level features
    grls = list(...)

    ## check the input
    if(any(sapply(grls, function(x) class(x) != "GRangesList")))
        stop("All inputs must be a GRangesList")

    ## annoying acrobatics to reconcile gr and grl level features for heterogenous input gr / grls
    grls.ul = lapply(grls, grl.unlist)
    grls.ul.rb = do.call('grbind', grls.ul)
    sp = base::unlist(lapply(1:length(grls), function(x) rep(x, length(grls.ul[[x]]))))
    gix = base::split(grls.ul.rb$grl.ix, sp)
    gjx = base::split(1:length(grls.ul.rb), sp)
    grls.ul.rb$grl.iix = grls.ul.rb$grl.ix = NULL

    grls.vals = lapply(grls, function(x)
    { if (ncol(mcols(x))>0)  return(as.data.frame(mcols(x))) else return(data.frame(dummy241421 = rep(NA, length(x))))})

    grls.new = mapply(function(x,y) GenomicRanges::split(grls.ul.rb[x],y), gjx, gix)

    ## do.call('c', grls.new) is not working for some reason (gives back list again, not GRangesList)
    ## have to do this instead, not ideal
    if (length(grls.new) > 1) {
        out = grls.new[[1]]
        for (i in 2:length(grls.new))
            out = c(out, grls.new[[i]])
    } else {
        out = grls.new[[1]]
    }

                                        # out = do.call('c', grls.new)
                                        #
                                        # if (is.list(out))
                                        #   {
                                        #     if (length(grls.new)>1)
                                        #       {
                                        #         bla = c(grls.new[[1]], grls.new[[2]]) ## fix R ghost
                                        #         out = do.call('c', grls.new)
                                        #         if (is.list(out)) ## if still is list then do manual 'c'
                                        #              {
                                        #                out = grls.new[[1]]
                                        #                for (i in 2:length(grls.new))
                                        #                    out = c(out, grls.new[[i]])
                                        #             }
                                        #       }
                                        #     else
                                        #       out = grls.new[[1]]
                                        #   }

    out.val = do.call('rrbind', grls.vals)
    out.val$dummy241421 = NULL
    GenomicRanges::mcols(out) <- out.val

    return(out)
}

#' Prepend "chr" to \code{GRanges seqlevels}
#'
#' @param gr \code{GRanges} object to append 'chr' to
#' @return Identical \code{GRanges}, but with 'chr' prepended to each seqlevel
#' @examples
#' gr <-  gr.chr(GRanges(c(1,"chrX"), IRanges(c(1,2), 1)))
#' seqnames(gr)
#' @importFrom GenomeInfoDb seqlevels seqlevels<-
#' @export
gr.chr = function(gr)
{
    if (any(ix <- !grepl('^chr', seqlevels(gr))))
        seqlevels(gr)[ix] = paste('chr', seqlevels(gr)[ix], sep = "")
    return(gr)
}

#' Reduce \code{GRanges} and \code{GRangesList} to miminal footprint
#'
#' Shortcut for \code{reduce(sort(gr.stripstrand(unlist(x))))}
#' @param gr \code{GRanges} or \code{GRangesList}
#' @param pad Expand the input data before reducing. \code{[0]}
#' @param sort Flag to sort the output. \code{[TRUE]}
#' @return \code{GRanges} object with no strand information, representing a minimal footprint
#' @importFrom GenomicRanges reduce
#' @examples
#' streduce(grl.hiC, pad=10)
#' streduce(example_genes, pad=1000)
#' @export
streduce = function(gr, pad = 0, sort = TRUE)
{

    if (inherits(gr, 'GRangesList'))
        gr = unlist(gr)

    if (any(is.na(seqlengths(gr))))
        gr = gr.fix(gr)

                                        #out = suppressWarnings(sort(reduce(gr.stripstrand(gr+pad))))
    out = suppressWarnings(sort(reduce(gr.stripstrand(gr + pad))))
    suppressWarnings(start(out) <-pmax(1, start(out)))
                                        #    out <- gr.tfix(out)
    end(out) = pmin(end(out), seqlengths(out)[as.character(seqnames(out))])


    return(out)
}

#' Return UCSC style interval string corresponding to \code{GRanges} pile (ie chr:start-end)
#'
#' @param gr \code{GRanges} pile to get intervals from
#' @param add.chr Prepend seqnames with "chr" \code{[FALSE]}
#' @param mb Round to the nearest megabase \code{[FALSE]}
#' @param round If \code{mb} supplied, how many digits to round to. \code{[3]}
#' @param other.cols Names of additional \code{mcols} fields to add to the string (seperated by ";")
#' @name gr.string
#' @examples
#' gr.string(example_genes, other.cols = c("name", "name2"))
#' @export
#' @author Marcin Imielinski
gr.string = function(gr, add.chr = FALSE, mb = FALSE, round = 3, other.cols = c(), pretty = FALSE)
{
    if (length(gr)==0)
        return(as.character(NULL))
    sn = as.character(seqnames(gr));
    if (add.chr)
        sn = paste('chr', sn, sep = '');

    other.cols = intersect(names(values(gr)), other.cols)
    if (length(other.cols)>0)
        other.str = paste(' ', do.call('paste', c(lapply(other.cols, function(x) values(gr)[, x]), list(sep = ' '))))
    else
        other.str = ''

    str = ifelse(as.logical(strand(gr)!='*'), as.character(strand(gr)), '')

    if (mb)
        return(paste(sn, ':', round(start(gr)/1e6, round), '-', round(end(gr)/1e6, round), str, other.str, sep = ''))
    else
        if (pretty)
            return(paste(sn, ':', stringr::str_trim(prettyNum(start(gr), big.mark = ',')), '-', stringr::str_trim(prettyNum(end(gr), big.mark = ',')), str, other.str, sep = ''))
    else
        return(paste(sn, ':', start(gr), '-', end(gr), str, other.str, sep = ''))
}


gr1 = GRanges(seqnames = "chr2", ranges = IRanges(3, 6), strand = "+", score = 5L, GC = 0.45)
gr2 = GRanges(seqnames = c("chr1", "chr1"), ranges = IRanges(c(7,13), width = 3), strand = c("+", "-"), score = 3:4, GC = c(0.3, 0.5))
gr3 = GRanges(seqnames = c("chr1", "chr2"), ranges = IRanges(c(1, 4), c(3, 9)), strand = c("-", "-"), score = c(6L, 2L), GC = c(0.4, 0.1))
grl = GRangesList("gr1" = gr1, "gr2" = gr2, "gr3" = gr3)


#' @name grl.reduce
#' @title grl.reduce
#' @description
#'
#' Quickly ranges inside grl +/- pad
#' Can use with split / unlist
#'
#' @param grl \code{GRangesList} 
#' @param pad padding to add to ranges inside grl before reduing
#' 
#' @return \code{GRangesList} with reduced intervals
#' @examples
#' gr1 = GRanges(seqnames = "chr2", ranges = IRanges(3, 6), strand = "+", score = 5L, GC = 0.45)
#' gr2 = GRanges(seqnames = c("chr1", "chr1"), ranges = IRanges(c(7,13), width = 3), strand = c("+", "-"), score = 3:4, GC = c(0.3, 0.5))
#' gr3 = GRanges(seqnames = c("chr1", "chr2"), ranges = IRanges(c(1, 4), c(3, 9)), strand = c("-", "-"), score = c(6L, 2L), GC = c(0.4, 0.1))
#' grl = GRangesList("gr1" = gr1, "gr2" = gr2, "gr3" = gr3)
#' grl.reduce(grl, 1000)
#' 
#' unlist(grl.reduce(split(reads+10000, reads$BX)))
#' 
#' @export
#' @author Marcin Imielinski
grl.reduce = function(grl, pad =0, clip = FALSE)
{
  sl = data.table(lev = seqlevels(grl), len = seqlengths(grl))
  setkey(sl, lev)
  gr = grl.unlist(grl)

  if (clip) ## clip to seqlengths
    {
      start(gr) = pmax(1, start(gr)-pad)
      end(gr) = pmin(sl[as.character(seqnames(gr)), len], end(gr)+clip, na.rm = TRUE)
    }
  else
    gr = gr + pad

  gr$group = gr$grl.ix

  grd = data.table(chr = as.character(seqnames(gr)), pos = c(start(gr), end(gr)), type = rep(as.numeric(c(1,-1)), each = length(gr)), group = rep(gr$group, 2))
  setkeyv(grd, c('group', 'chr', 'pos'))
  grd[, cs := cumsum(type), by = group]
  grd[, run := label.runs(cs!=0), by = group][, run := ifelse(is.na(run), c(NA, run[-length(run)]), run)][, run := paste(group, run)]
  out = grd[, .(chr = chr[1], start = pos[1], end = pos[length(pos)], group = group[1]), by = run]
  out.gr = dt2gr(out)
  out.grl = split(out.gr, factor(out.gr$group, 1:length(grl)))
  values(out.grl) = values(grl)
  if (!is.null(names(grl)))
      names(out.grl) = names(grl)
  return(out.grl)
}


#' Create string representation of \code{GRangesList}
#'
#' Return ucsc style interval string corresponding to each \code{GRanges} in the \code{GRangesList}.
#' One line per per \code{GRangesList} item. \code{GRanges} elements themselves are separated by \code{sep}
#'
#' @param grl \code{GRangesList} to convert to string vector
#' @param mb Will return as MB and round to "round" [FALSE]
#' @param sep Character to separate single \code{GRanges} ranges [,]
#' @param ... Additional arguments to be passed to \code{gr.string}
#' @return Character vector where each element is a \code{GRanges} pile corresponding to a single \code{GRangesList} element
#' @name grl.string
#' @examples
#' grl.string(grl.hiC, mb=TRUE)
#' @author Marcin Imielinski
#' @export
grl.string = function(grl, mb= FALSE, sep = ',', ...)
{

    if (class(grl) == "GRanges")
        return(gr.string(grl, mb=mb, ...))

    if (class(grl) != "GRangesList")
        stop("Input must be GRangesList (or GRanges, which is sent to gr.string)")

    gr = grl.unlist(grl)
    if (!is.null(names(grl)))
        nm = names(grl)
    else
        nm = 1:length(grl)

    grs = gr.string(gr, mb=mb, ...)
    out = sapply(split(grs, gr$grl.ix), paste, collapse = sep)
    names(out) = nm[as.numeric(names(out))]
    return(out)
}

#' "Fixes" \code{seqlengths} / \code{seqlevels}
#'
#' If "genome" not specified will replace \code{NA} \code{seqlengths} in GRanges to reflect largest coordinate per \code{seqlevel}
#' and removes all \code{NA seqlevels} after this fix.
#'
#' if "genome" defined (i.e. as \code{Seqinfo} object, or a \code{BSgenome}, \code{GRanges}, \code{GRangesList} object with populated \code{seqlengths}),
#' then will replace \code{seqlengths} in \code{gr} with those for that genome
#' @name gr.fix
#' @param gr \code{GRanges} object to fix
#' @param genome Genome to fix to: \code{Seqinfo}, \code{BSgenome}, \code{GRanges} (w/seqlengths), \code{GRangesList} (w/seqlengths)
#' @param gname Name of the genome (optional, just appends to \code{Seqinfo} of the output) [NULL]
#' @param drop Remove ranges that are not present in the supplied genome [FALSE]
#' @return \code{GRanges} pile with the fixed \code{Seqinfo}
#' @importFrom GenomeInfoDb Seqinfo seqinfo keepSeqlevels seqlevels seqlengths seqlevels<- seqlengths<- genome<- seqnames
#' @export
gr.fix = function(gr, genome = NULL, gname = NULL,  drop = FALSE)
{
#### marcin: now it is
    ## if (inherits(gr, "GRangesList"))
    ##   stop("gr.fix not setup to take GRangesList")

    sn = V1 = NULL ## NOTE fix

    if (!is.null(genome))
    {
        if (is.vector(genome))  ## assume seqlengths was provided (ie named vector of lengths)
            genome = Seqinfo(names(genome), seqlengths = genome)
        else if (!(is(genome, 'character') | inherits(genome, 'GRanges') | inherits(genome, 'BSgenome') | inherits(genome, 'GRangesList') | inherits(genome, 'Seqinfo')) & !is.vector(genome))
            genome = seqinfo(genome)

        if (!is.vector(genome))
            if (!drop)
            {
                levs = union(seqlevels(genome), as.character(seqnames(seqinfo(gr))))
                lens = structure(rep(NA, length(levs)), names = levs)
                lens[seqlevels(genome)] = seqlengths(genome);
                lens[seqlevels(gr)] = pmax(seqlengths(gr), lens[seqlevels(gr)], na.rm = TRUE)
            }
            else
                lens = structure(seqlengths(genome), names = seqlevels(genome))
                                        # else
                                        #   {
                                        #     if (is.character(genome))
                                        #       genome = structure(rep(NA, length(genome)), names = genome)
                                        #
                                        #     lens = structure(NA, names = union(names(genome), seqlevels(gr)));
                                        #
                                        #     lens[seqlevels(gr)] = seqlengths(gr);
                                        #     lens[names(genome)[!is.na(genome)]] = pmax(lens[names(genome)[!is.na(genome)]], genome[!is.na(genome)], na.rm = TRUE)
                                        #
                                        #     if (drop)
                                        #       lens = lens[names(genome)]
                                        #   }

        seqlevels(gr) = names(lens)
        seqlengths(gr) = lens;
    }
    else
    {
        if (length(gr)>0)
        {
            if (is(gr, 'GRangesList'))
                tmp.gr = unlist(gr)
            else
                tmp.gr = gr

            tmp.sl = data.table(sn = as.character(seqnames(tmp.gr)), end = end(tmp.gr))[, max(end, na.rm = TRUE), by = sn][,  structure(V1, names = sn)][seqlevels(tmp.gr)]
            names(tmp.sl) = seqlevels(tmp.gr)
            seqlengths(tmp.gr)[!is.na(tmp.sl)] = suppressWarnings(pmax(tmp.sl[!is.na(tmp.sl)], seqlengths(tmp.gr)[!is.na(tmp.sl)], na.rm = TRUE))
            gr = tmp.gr
        }
        if (drop)
            gr = keepSeqlevels(gr, seqlevels(gr)[!is.na(seqlengths(gr))])

    }

    ## hack to get rid of annoying "genome"
    if (!is.null(gname))
    {
        si = seqinfo(gr)
        genome(si) = gname
        gr@seqinfo = si
    }

    return(gr)
}


#' Lay ranges end-to-end onto a derivate "chromosome"
#'
#' Takes pile of \code{GRanges} and returns into a \code{data.frame} with \code{nrow = length(gr)} with each
#' representing the corresponding input range superimposed onto a single "flattened"
#' chromosome, with ranges laid end-to-end
#' @param gr \code{GRanges} to flatten
#' @param gap Number of bases between ranges on the new chromosome \code{[0]}
#' @return \code{data.frame} with start and end coordinates, and all of the original metadata
#' @name gr.flatten
#' @importFrom GenomicRanges mcols
#' @export
gr.flatten = function(gr, gap = 0)
{
    if (length(gr) == 0)
        return(data.frame())
    else if (length(gr) == 1)
        return(data.frame(start = 1, end = width(gr)))
    else
    {
        starts = as.numeric(cumsum(c(1, width(gr[1:(length(gr)-1)])+gap)))
        ends = as.numeric(starts+width(gr)-1)
        return(cbind(data.frame(start=starts, end=ends), as.data.frame(mcols(gr))))
    }
}

#' gr.stripstrand
#'
#' Sets strand to "*"
#' @name gr.stripstrand
#' @param gr \code{GRanges} to remove strand information from
#' @return \code{GRanges} with strand set to \code{*}
#' @export
gr.stripstrand = function(gr)
{
    strand(gr) = "*"
    return(gr)
}

#' Create pairs of ranges and their strand-inverse
#'
#' From a \code{GRanges} returns a \code{GRangesList} with each item consisting
#' of the original \code{GRanges} and its strand flip
#' @name gr.pairflip
#' @param gr \code{GRanges}
#' @return \code{GRangesList} with each element of length 2
#' @export
gr.pairflip = function(gr)
{
    strand(gr)[strand(gr) =='*'] = '+';
    return(split(c(gr, gr.flip(gr)), rep(c(1:length(gr)), 2)))
}

#' Flip strand on \code{GRanges}
#'
#' @name gr.flipstrand
#' @param gr \code{GRanges} pile with strands to be flipped
#' @return \code{GRanges} with flipped strands (+ to -, * to *, - to *)
#' @examples
#' gr.flipstrand(GRanges(1, IRanges(c(10,10,10),20), strand=c("+","*","-")))
#' @export
gr.flipstrand <- gr.flip <- function(gr)
                 {
                     if (!is(gr, 'GRanges'))
                         stop('GRanges input only')

                     if (length(gr)==0)
                         return(gr)

                     which = cbind(1:length(gr), TRUE)[,2] == 1

                     if (any(which))
                         strand(gr)[which] = c('*'='*', '+'='-', '-'='+')[as.character(strand(gr))][which]

                     return(gr)
                 }

#' Tile ranges across \code{GRanges}
#'
#' Tiles interval (or whole genome) with segments of \code{<=} specified width.
#' @param gr \code{GRanges}, \code{seqlengths} or \code{Seqinfo} range to tile. If has \code{GRanges} has overlaps, will reduce first.
#' @param w Width of each tile
#' @name gr.tile
#' @examples
#' ## 10 tiles of width 10
#' gr1 <- gr.tile(GRanges(1, IRanges(1,100)), w=10)
#' ## make them overlap each other by 5
#' gr1 + 5
#' @export
gr.tile = function(gr, w = 1e3)
{
    numw = tile.id = query.id = NULL ## getting past NOTE
    if (!is(gr, 'GRanges'))
        gr = si2gr(gr);

    ix = which(width(gr)>0)
    gr = gr[ix]

    if (length(gr)==0)
        return(gr[c()][, c()])

    ws = as.numeric(ceiling((width(gr))/w))

    st = rep(start(gr), ws)
    en = rep(end(gr), ws)
    strand = rep(as.character(strand(gr)), ws)
    dt = data.table(query.id = rep(1:length(gr), ws), tile.id = 1:sum(ws))
    dt[, numw := 0:(length(tile.id)-1), by = query.id]
    start = pmin(st+w*dt$numw, en)
    end = pmin(st+w*(dt$numw+1)-1, en)

    out = GRanges(rep(as.character(seqnames(gr)), ws), IRanges(start, end), strand = strand, query.id = ix[dt$query.id], tile.id = 1:length(start), seqinfo = seqinfo(gr))

    return(out)
}

#' gr.tile.map
#'
#' Given two tilings of the genome (e.g. at different resolution)
#' query and subject outputs a length(query) list whose items are integer vectors of indices in subject
#' overlapping that overlap that query (strand non-specific)
#'
#' @param query Query \code{GRanges} pile, perhaps created from some tile (e.g. \code{gr.tile}), and assumed to have no gaps
#' @param subject Subject \code{GRanges} pile, perhaps created from some tile (e.g. \code{gr.tile}), and assumed to have no gaps
#' @param verbose Increase the verbosity of the output
#' @return \code{list} of length = \code{length(query)}, where each element \code{i} is a vector of indicies in \code{subject} that overlaps element \code{i} of \code{query}
#' @note Assumes that input query and subject have no gaps (including at end) or overlaps, i.e. ignores end()
#' coordinates and only uses "starts"
#' @author Marcin Imielinski
#' @export
gr.tile.map = function(query, subject, verbose = FALSE)
{

    mc.cores =1 ## multicore not supported now
    if (length(GenomicRanges::gaps(query)) > 0)
        warning("Query GRanges has gaps. Unexpected behavior may follow")
    if (length(GenomicRanges::gaps(subject)) > 0)
        warning("Subject GRanges has gaps. Unexpected behavior may follow")

    ix.q = order(query)
    ix.s = order(subject)

    q.chr = as.character(seqnames(query))[ix.q]
    s.chr = as.character(seqnames(subject))[ix.s]

    ql = base::split(ix.q, q.chr)
    sl = base::split(ix.s, s.chr)

    tmp <- parallel::mcmapply(
                                        #tmp <- lapply(
        function(x,y)
        {
            if (length(y)==0)
                return(NULL)
            all.pos = c(start(query)[x], start(subject)[y])
            is.q = c(rep(T, length(x)), rep(F, length(y)))
            all.ix = c(x, y)
            ord.ix = order(all.pos)
            all.pos = all.pos[ord.ix]
            is.q = is.q[ord.ix]
            all.ix = all.ix[ord.ix]
            out = matrix(NA, nrow = length(all.pos), ncol = 2)
            last.x = last.y = NA
            for (i in 1:length(all.pos))
            {
                if (verbose)
                    if (i %% 100000 == 0) cat('Iteration', i, 'of', length(all.pos), '\n')
                if (is.q[i])
                {
                    out[i, ] = c(all.ix[i], last.y)

                    if (i<length(all.pos)) ## edge case where subject and query intervals share a start point, leading to two consecutive all.pos
                        if (all.pos[i] == all.pos[i+1])
                            out[i, ] = NA

                    last.x = all.ix[i]
                }
                else
                {
                    out[i, ] = c(last.x, all.ix[i])

                    if (i<length(all.pos)) ## edge case where subject and query intervals share a start point, leading to two consecutive all.pos
                        if (all.pos[i] == all.pos[i+1])
                            out[i, ] = NA

                    last.y = all.ix[i]
                }
            }
            out = out[rowSums(is.na(out))==0, ]
            return(out)
        }, ql, sl[names(ql)], mc.cores = mc.cores, SIMPLIFY = FALSE)
                                        #}, ql, sl[names(ql)], SIMPLIFY = FALSE)

    m = munlist(tmp)[, -c(1:2), drop = FALSE]
    out = split(m[,2], m[,1])[as.character(1:length(query))]
    names(out) = as.character(1:length(query))
    return(out)
}

#' Annotate \code{GRanges} with values from another \code{GRanges}
#'
#' Annotates \code{GRanges} in \code{query} with aggregated values of \code{GRanges} in \code{target} in field \code{val}.
#' If \code{val} is numeric: given \code{target} with value column \code{target} representing ranged data
#' (i.e. segment intensities), thn computes the value
#' in each \code{query} \code{GRanges} as the weighted mean of its intersection with target
#' (ie the target values weighted by the width of the intersections).
#'
#' Applications include (among others):
#' \itemize{
#' \item Querying the average value of target across a given query interval (e.g. exon to gene pileup)
#' \item recasting a high res tiling in terms of low res intervals.
#' }
#' Usually query intervals are bigger than the target intervals.
#'
#' @note \code{query} and \code{target} can be \code{GRangesList} object, in which case val will refer to \code{GRangesList} level values fields
#' @name gr.val
#' @param val If a character field: then aggregation will paste together the (unique), overlapping values, collapsing by comma. \code{[NULL]}
#' @param weighted Calculate a weighted mean. If \code{FALSE}, calculates unweighted mean. \code{[TRUE]}
#' @param na.rm Remove NA values when calulating means. only applies if val column of target is numeric \code{[FALSE]}
#' @param query \code{GRanges} of query ranges whose \code{val} column we will populate with aggregated values of \code{target}
#' @param target \code{GRanges} of target ranges that already have "val" column populated
#' @param FUN Optional different function to call than mean. Takes two arguments (value, na.rm = TRUE) if weighted = FALSE, and three (value, width, na.rm = TRUE) if weighted = TRUE
#' @param mean Scalar logical flag. If \code{FALSE} then will return sum instead of mean, only applies if target \code{val} column is numeric.
#' @param sep scalar character, specifies character to use as separator when aggregating character "vals" from target, only applies if target is character
#' @param by scalar character, specifies additional "by" column of query AND target that will be used to match up query and target pairs (i.e. in addition to pure GRanges overlap), default is NULL
#' @param max.slice Maximum number of query ranges to consider in one memory chunk. \code{[Inf]}
#' @param merge if merge = FALSE then will cross every range in query with every level of "by" in target (and create data matrix), otherwise will assume query has "by" and merge only ranges that have matching "by" values in both query and target
#' @param verbose Increase the verbosity of the output
#' @param mc.cores Number of cores to use when running in chunked mode
#' @param by.prefix Choose a set of \code{val} fields by a shared prefix.
#' @param default.val If no hit in \code{target} found in \code{query}, fill output \code{val} field with this value.
#' @param ... Additional arguments to be sent to \code{\link{gr.findoverlaps}}.
#' @return \code{query} with the \code{val} field populated
#' @author Marcin Imielinski
#' @export
gr.val = function(query, target,
                  val = NULL,
                  mean = TRUE,
                  weighted = mean,
                  na.rm = FALSE,
                  by = NULL,
                  by.prefix = val,
                  merge = FALSE,
                  verbose = FALSE,
                  FUN = NULL,
                  ##ignore.strand = TRUE,
                  default.val = NA,
                  max.slice = Inf,
                  mc.cores = 1,  ## is slicing how many cores to split across
                  ...,
                  sep = ', '
                  )
{
    query.id = subject.id = NULL ## fix NOTE

    if (is.null(val))
        val = 'value'


    if (!(all(ix <- val %in% names(values(target)))))
        values(target)[, val[!ix]] = 1

    if (length(query)>max.slice)
    {
        verbose = TRUE
        ix.l = split(1:length(query), ceiling(as.numeric((1:length(query)/max.slice))))
        return(do.call('grbind', parallel::mclapply(ix.l, function(ix) {
            if (verbose)
                cat(sprintf('Processing %s to %s of %s\n', min(ix), max(ix), length(query)))
            gr.val(query[ix, ], target = target, val= val, mean = mean, weighted = weighted, na.rm = na.rm, verbose = TRUE, by = by, FUN = FUN, merge = merge, ...)
        }, mc.cores = mc.cores)))
    }

    if (inherits(target, 'GRangesList'))
    {
        target.was.grl = TRUE;
        target.grl.id = as.data.frame(target)$element
        val.vec = lapply(val, function(x) values(target)[, x])
        target = unlist(target)
        val.vec = lapply(val.vec, function(X) val.vec[target.grl.id])
    }
    else
    {
        if (!is.null(val))
            val.vec = lapply(val, function(x) values(target)[, x])
        else
            val.vec = list(rep(1, length(target)))

        target.grl.id = 1:length(target);
        target.was.grl = FALSE;
    }

    if (inherits(query, 'GRangesList'))
    {
        query.was.grl = TRUE;
        query.grl.id = rep(1:length(query), S4Vectors::elementNROWS(query))
        query = unlist(query)
    }
    else
    {
        query.grl.id = 1:length(query);
        query.was.grl = FALSE;
    }

    if (!is.null(FUN))
    {
        args = names(formals(FUN))[1:3]

        if (!is.null(args))
        {
            if (any(is.na(args)))
                args[is.na(args)] = ''

            if (weighted)
            {
                if (any(!(c('x', 'w', 'na.rm') %in% args)))
                    warning('FUN input must be function with three arguments: "x" = value, "w" = interval width, "na.rm" = na.rm flag')
            }
            else
            {
                if (any(!(c('x', 'na.rm') %in% args)))
                    warning('FUN input must be function with two arguments: "x" = value, "na.rm" = na.rm flag')
            }
        }
    }

    if (!merge)
        hits = gr.findoverlaps(query, target, scol = by, verbose = verbose, return.type = 'data.table', ...)
    else
        hits = gr.findoverlaps(query, target, by = by, verbose = verbose, return.type = 'data.table', ...)

    if (verbose)
        cat(sprintf('aggregating hits\n'))

    vals = val
    val.vecs = val.vec

    for (vix in 1:length(vals))
    {
        val = vals[[vix]]
        val.vec = val.vecs[[vix]]
        is.char = is.character(values(target)[, val]);
        if (is.null(by) | merge == TRUE)
        {
            if (nrow(hits)>0)
            {
                values(query)[, val] = NA;
                hits[, width := as.numeric(end - start)+1]
                data.table::setkey(hits,  query.id)
                if (is.char)
                {
                    values(query)[, val] = '';
                    hits$id = 1:nrow(hits);
                    if (!is.null(FUN))
                        tmp = hits[, list(val = do.call(FUN, list(val.vec[subject.id], width, na.rm = na.rm))), by = query.id]
                    else
                        tmp = hits[, list(val = paste(setdiff(val.vec[subject.id], NA), collapse = sep)), by = query.id]
                    if (!is.na(default.val))
                        tmp[is.na(tmp)] = default.val
                    values(query)[tmp[,query.id], val] = tmp[,val]
                }
                else
                {

                                        #            val.vec = as.numeric(values(target)[, val]);
                    val.vec = as.numeric(val.vec)
                    if (weighted)
                    {
                        if (!is.null(FUN))
                            tmp = hits[, list(val = do.call(FUN, list(val.vec[subject.id], width, na.rm = na.rm))), by = query.id]
                        else if (mean)
                            tmp = hits[, list(val = sum(width * val.vec[subject.id], na.rm = na.rm)/sum(width)), by = query.id]
                        else
                            tmp = hits[, list(val = sum(width * val.vec[subject.id], na.rm = na.rm)), by = query.id]
                    }
                    else
                    {
                        if (!is.null(FUN))
                            tmp = hits[, list(val = do.call(FUN, list(val.vec[subject.id], na.rm = na.rm))), by = query.id]
                        else if (mean)
                            tmp = hits[, list(val =  mean(val.vec[subject.id], na.rm = na.rm)), by = query.id]
                        else
                            tmp = hits[, list(val = sum(val.vec[subject.id], na.rm = na.rm)), by = query.id]
                    }

                    if (!is.na(default.val))
                        tmp[is.na(tmp)] = default.val

                    values(query)[tmp[,query.id], val] = tmp[,val]
                }
            }
            else
                values(query)[, val] = NA
        }
        else ## by is not null
        {

            if (!is.null(by.prefix))
                if (is.na(by.prefix))
                    by.prefix = NULL
                else if (nchar(by.prefix)==0)
                    by.prefix = NULL

            if (nrow(hits)>0)
            {
                hits[, width := as.numeric(end - start)+1]
                if (is.char)
                {
                    hits$id = 1:nrow(hits);
                    tmp = hits[, list(val = paste(setdiff(val.vec[subject.id], NA), collapse = sep)), keyby = list(query.id, bykey = eval(parse(text=by)))]

                    tmp2 = data.table::dcast.data.table(tmp, query.id ~ bykey, value.var = 'val')
                    data.table::setkey(tmp2, query.id)
                    new.df = as.data.frame(tmp2[list(1:length(query)), ])[ ,-1]

                    if (!is.na(default.val))
                        new.df[is.na(new.df)] = default.val

                    if (!is.null(by.prefix))
                        colnames(new.df) =  paste(by.prefix, names(tmp2)[-1], sep = '.')
                    else
                        colnames(new.df) =  names(tmp2)[-1]
                    new.names = c(colnames(values(query)), colnames(new.df))
                    values(query) = cbind(values(query), new.df)
                    colnames(values(query)) = new.names
                }
                else
                {

                                        #            val.vec = as.numeric(values(target)[, val]);
                    val.vec = as.numeric(val.vec)
                    if (weighted)
                    {
                        if (!is.null(FUN))
                        {
                            tmp = hits[, list(val = do.call(FUN, list(val.vec[subject.id], width, na.rm = na.rm))), keyby = list(query.id, bykey = eval(parse(text=by)))]
                        }
                        else if (mean)
                            tmp = hits[, list(val = sum(width * val.vec[subject.id], na.rm = na.rm)/sum(width)), keyby = list(query.id, bykey = eval(parse(text=by)))]
                        else
                            tmp = hits[, list(val = sum(width * val.vec[subject.id], na.rm = na.rm)), keyby = list(query.id, bykey = eval(parse(text=by)))]
                    }
                    else
                    {
                        if (!is.null(FUN))
                            tmp = hits[, list(val = do.call(FUN, list(val.vec[subject.id], na.rm = na.rm))), keyby = list(query.id, bykey = eval(parse(text=by)))]
                        else if (mean)
                            tmp = hits[, list(val =  mean(val.vec[subject.id], na.rm = na.rm)), keyby = list(query.id, bykey = eval(parse(text=by)))]
                        else
                            tmp = hits[, list(val = sum(val.vec[subject.id], na.rm = na.rm)), keyby = list(query.id, bykey = eval(parse(text=by)))]
                    }

                    tmp2 = data.table::dcast.data.table(tmp, query.id ~ bykey, value.var = 'val')
                    data.table::setkey(tmp2, query.id)
                    new.df = as.data.frame(tmp2[list(1:length(query)), ])[ ,-1, drop = FALSE]

                    if (!is.na(default.val))
                        new.df[is.na(new.df)] = default.val

                    if (!is.null(by.prefix))
                        colnames(new.df) =  paste(by.prefix, names(tmp2)[-1], sep = '.')
                    else
                        colnames(new.df) =  names(tmp2)[-1]

                    new.names = c(colnames(values(query)), colnames(new.df))
                    values(query) = cbind(values(query), new.df)
                    colnames(values(query)) = new.names
                }
            }
            else
                for (val in levels(factor(subject$by)))
                    values(query)[, val] = NA
        }
    }

    if (query.was.grl)
        query = split(query, query.grl.id)

    return(query)
}


#' Allows to restrict duplicates using "by" columns and allows in exact matching
#'
#' @param query  query ranges
#' @name gr.duplicated
#' @examples
#' gr.duplicated(GRanges(c(1,1,1), IRanges(c(2,5,5), width=1)))
#'
#' @examples gr.duplicated(GRanges(c(1,1,1), IRanges(c(2,5,5), width=1)))
#' 
#' @export
gr.duplicated = function(query, by = NULL, type = 'any')
{
    return(duplicated(gr.match(query, query, by = by , type = type)))
}

#' Dice up \code{GRanges} into \code{width = 1} \code{GRanges} spanning the input (warning can produce a very large object)
#'
#' @param gr \code{GRanges} object to dice
#' @name gr.dice
#' @importFrom S4Vectors Rle
#' @importFrom GenomeInfoDb seqlengths
#' @importFrom GenomicRanges seqnames width strand values<- values strand<- distance
#' @return \code{GRangesList} where kth element is a diced pile of \code{GRanges} from kth input \code{GRanges}
#' @examples
#' gr.dice(GRanges(c(1,4), IRanges(c(10,10),20)))
#' @author Marcin Imielinski
#' @export
gr.dice = function(gr)
{
    sn = Rle(as.character(seqnames(gr)), width(gr))
    tmp.st = start(gr)
    tmp.en = end(gr)
    st = unlist(lapply(1:length(gr), function(x) tmp.st[x]:tmp.en[x]))
    str = Rle(as.character(strand(gr)), width(gr))

    ## reverse for negative strand ranges
    if (any(ix <- as.logical(strand(gr) == '-')))
    {
        w = width(gr)
        q.id = unlist(lapply(1:length(gr), function(x) rep(x, w[x])))
        q.l = split(1:length(st), q.id)

        for (j in q.l[ix])
            st[j] = rev(st[j])
    }

    ix = Rle(1:length(gr), width(gr))
    out = GRanges(sn, IRanges(st, st), strand = str, seqlengths = seqlengths(gr))
    values(out) = values(gr)[ix, ]

    out = GenomicRanges::split(out, ix)

    return(out)
}


#' Pairwise distance between two \code{GRanges}
#'
#' Computes matrix of pairwise distance between elements of two \code{GRanges} objects of length \code{n} and \code{m}.
#'
#' Distances are computed as follows:
#' \itemize{
#' \item NA for ranges on different seqnames
#' \item 0 for overlapping ranges
#' \item min(abs(end1-end2), abs(end1-start2), abs(start1-end2), abs(start1-end1),) for all others
#' }
#' If only \code{gr1} is provided, then will return n x n matrix of \code{gr1} vs itself \cr
#' If \code{max.dist = TRUE}, then will replace \code{min} with \code{max} above
#' @param gr1 First \code{GRanges}
#' @param gr2 Second \code{GRanges}
#' @param ignore.strand Don't required elements be on same strand to avoid \code{NA [FALSE]}
#' @param ... Additional arguments to be supplied to \code{GenomicRanges::distance}
#' @return \code{N} by \code{M} matrix with the pairwise distances, with \code{gr1} on rows and \code{gr2} on cols
#' @name gr.dist
#' @author Marcin Imielinski
#' @export
gr.dist = function(gr1, gr2 = NULL, ignore.strand = FALSE, ...)
{
    if (is.null(gr2))
        gr2 = gr1;

    if (ignore.strand)
    {
        strand(gr1) = '*'
        strand(gr2) = '*'
    }

    ix1 = rep(1:length(gr1), length(gr2))
    ix2 = rep(1:length(gr2), each = length(gr1))

    out = matrix(suppressWarnings(distance(gr1[ix1], gr2[ix2], ...)), nrow = length(gr1), ncol = length(gr2))

    return(out)
}

#' Remove \code{GRanges} names inside a \code{GRangesList}
#' @param grl \code{GRangesList} with names elements
#' @return \code{GRangesList} where \code{GRanges} have no names
#' @name grl.stripnames
grl.stripnames = function(grl)
{
    ele = tryCatch(as.data.frame(grl)$element, error = function(e) e)
    if (inherits(ele, 'error'))
        ele = unlist(lapply(1:length(grl), function(x) rep(x, length(grl[[x]]))))

    gr = unlist(grl);
    names(gr) = NULL;

    out = split(gr, ele);
    values(out) = values(grl)
    names(out) = names(grl)

    return(out)
}

#' Queries an \code{\link{RleList}} representing genomic data
#'
#' (ie a list whose names represent seqnames ie chromosomes, and lengths represent seqlengths)
#' via \code{GRanges} object
#'
#' @param subject.rle \code{Rle}
#' @param mc.cores Number of cores to apply when doing chunked operation
#' @param query.gr TODO
#' @param verbose Set the verbosity of the output
#' @param chunksize Number of \code{query.gr} ranges to consider in one memory chunk. 1e9
#' @return Rle representing the (concatenated) vector of data (reversing order in case of negative strand input)
#' @note Throws warning if seqlengths(gr) do not correspond to the lengths of the \code{RleList} components
#' @export
rle.query = function(subject.rle, query.gr, verbose = FALSE, mc.cores = 1, chunksize = 1e9) ## mc.cores only relevant if there are over 1e9 bases to be queried from subject.rle
{
    was.grl = FALSE

    if (is(query.gr, 'GRangesList'))
    {
        was.grl = TRUE
        query.gr = grl.unlist(query.gr)
    }

    ##     if (!identical(names(subject.rle), seqlevels(query.gr)))
    ##       warning('seqlevels of subject and query are not the same')

    ##     com.seq = intersect(seqlevels(query.gr), names(subject.rle))

    ##     if (!identical(sapply(subject.rle[com.seq], length), seqlengths(query.gr)[com.seq]))
    ##       warning('seqlengths of subject and query are not the same')

    chunksize = pmin(1e9, chunksize)
    if ((sum(as.numeric(width(query.gr))))>chunksize) ## otherwise integer overflow
    {
        tmp = rle(ceiling(cumsum(as.numeric(width(query.gr)))/chunksize))
        chunks = cbind(cumsum(c(1, tmp$lengths[-length(tmp$lengths)])), cumsum(c(tmp$lengths)))
        if (verbose)
            cat(sprintf('chunking up into %s chunks \n', nrow(chunks)))
        out = do.call('c', parallel::mclapply(1:nrow(chunks), function(x) rle.query(subject.rle, query.gr[chunks[x,1]:chunks[x,2]]), mc.cores = mc.cores))
    }
    else
    {
        out = Rle(NA, sum(as.numeric(width(query.gr))));

        if (length(query.gr)>1)
        {
            st.ix = cumsum(c(1, width(query.gr)[1:(length(query.gr)-1)]))
        }else
        {
            st.ix = 1
        }
        out.ix = IRanges(st.ix, st.ix + width(query.gr)-1) ## ranges in out corresponding to query

        for (chr in intersect(names(subject.rle), unique(as.character(seqnames(query.gr)))))
        {
            ix = which(as.character(seqnames(query.gr)) == chr)
            rix = ranges(query.gr)[ix]
            m = max(end(rix))
            if (length(subject.rle[[chr]]) < m) ## pad subject rle if not long enough
            {
                subject.rle[[chr]] = c(subject.rle[[chr]], Rle(NA, m - length(subject.rle[[chr]])))
            }
            out[unlist(as.integer(out.ix[ix]))] = subject.rle[[chr]][rix]
        }

        if("-" %in% as.character(strand(query.gr)))
        {
            id = NULL; V1 = NULL ## NOTE fix
            tmp = data.table(ix = 1:sum(width(out.ix)), id = rep(1:length(out.ix), width(out.ix)), strand = rep(as.character(strand(query.gr)), width(out.ix)), key = 'ix')
            out = out[tmp[, rev(ix), by = id][, V1]]
            ## strand.col = c(1, 2)
            ## names(strand.col) = c("+", "-")
            ## cumsums = cumsum(width(out.ix))
            ## exon.max = rep(cumsums, times = width(out.ix))
            ## exon.min = rep(c(0, cumsums[1:(length(cumsums) - 1)]), times = width(out.ix))
            ## negs = exon.max - 0:(length(out)-1) + exon.min

            ## pos.neg.mat = cbind(1:length(out), negs)
            ## index = pos.neg.mat[cbind(1:length(out), strand.col[strand])]
            ## out = out[index]
        }
    }

    if (was.grl)
        out = split(out, Rle(query.gr$grl.ix, width(query.gr)))

    return(out)
}



#' Check intersection of \code{GRangesList} with windows on genome
#'
#' Like %in% for grl but now will return a logical vector that is true at position if i
#' only if the ranges in grl[i] intersect <<all>>, <<some>>, <<only>>  windows in the subject
#'
#' eg can use to identify read pairs whose ends are contained inside two genes)
#' @param grl \code{GRangesList} object to query for membership in \code{windows}
#' @param windows \code{GRanges} pile of windows
#' @param some Will return \code{TRUE} for \code{GRangesList} elements that intersect at least on window range [FALSE]
#' @param only Will return \code{TRUE} for \code{GRangesList} elements only if there are no elements of query that fail to interesect with windows [FALSE]
#' @param logical will return logical otherwise will return numeric vector of number of windows overlapping each grl
#' @param ... Additional parameters to be passed on to \code{GenomicRanges::findOverlaps}
#' @name grl.in
#' @export
grl.in <- function(grl, windows, some = FALSE, only = FALSE, logical = TRUE, exact = FALSE, ignore.strand = TRUE, ...)
{
    grl.iid = grl.id = NULL ## for getting past NOTE

    if (length(grl)==0)
      {
        if (logical)
          return(logical())
        else
          return(numeric())
      }

    if (length(windows)==0)
    {
      if (logical)
        return(rep(FALSE, length(grl)))
      else
        return(rep(0, length(grl)))
    }

    numwin = length(windows);

    gr = grl.unlist(grl)
    if (logical)
    {
        h = tryCatch(GenomicRanges::findOverlaps(gr, windows, ignore.strand = ignore.strand, ...), error = function(e) NULL)
        if (!is.null(h))
            m = data.table(query.id = queryHits(h), subject.id = subjectHits(h))
        else
            m = gr2dt(gr.findoverlaps(gr, windows, ignore.strand = ignore.strand, ...))
    }
    else
    {
#        some = FALSE
#        only = FALSE
      m = gr2dt(gr.findoverlaps(gr, windows, ignore.strand = ignore.strand, ...))
    }

    if (exact)
      m = m[start == start(gr)[query.id] & start == start(windows)[subject.id] & end == end(gr)[query.id] & end == end(windows)[subject.id], ]

    out = rep(FALSE, length(grl))
    if (nrow(m)==0)
        return(out)

    m$grl.id = gr$grl.ix[m$query.id]
    m$grl.iid = gr$grl.iix[m$query.id]

    if (some)
        tmp = as.data.frame(m[, length(unique(grl.iid)), by = grl.id])
    else if (only)
        return(base::mapply(function(x, y) length(setdiff(x, y))==0,
                            split(1:length(gr), factor(gr$grl.ix, 1:length(grl))),
                            split(m$query.id, factor(m$grl.id, 1:length(grl)))))
    else
        tmp = stats::aggregate(formula = subject.id ~ grl.id, data = m, FUN = function(x) numwin-length(setdiff(1:numwin, x)))

    out = rep(FALSE, length(grl))
    out[tmp[,1]] = tmp[,2]

    if (logical) ## DO NOT REMOVE!!
        out = out!=0
    return(out)
}

#' Robust unlisting of \code{GRangesList} that keeps track of origin
#'
#' Does a "nice" unlist of a \code{GRangesList} object adding a field \code{grl.ix} denoting which element of the \code{GRangesList}
#' each \code{GRanges} corresponds to and a field \code{grl.iix} which saves the (local) index that that gr was in its corresponding \code{GRangesList} item
#'
#' In this way, \code{grl.unlist} is reversible, while \code{BiocGenerics::unlist} is not.
#' @name grl.unlist
#' @importFrom BiocGenerics unlist
#' @param grl \code{GRangeList} object to unlist
#' @return \code{GRanges} with added metadata fields \code{grl.ix} and \code{grl.iix}.
#' @examples
#' grl.unlist(grl.hiC)
#' @export
grl.unlist = function(grl)
{
    if (length(grl) == 0) ## JEREMIAH
        return(GRanges())

    if (is(grl, 'GRanges'))

    {
        grl$grl.ix = 1
        grl$grl.iix = 1:length(grl)
        return(grl)
    }

    names(grl) = NULL
    as.df = as.data.frame(grl)

    el = as.df$element
    if (is.null(el))
        el = as.df$group

    out = BiocGenerics::unlist(grl)
    mcols(out)$grl.ix = el
    tmp = rle(el)

    nm = setdiff(names(values(grl)), c('grl.ix', 'grl.iix'))
    out$grl.iix = as.integer(unlist(sapply(tmp$lengths, function(x) 1:x)))
    values(out) = BiocGenerics::cbind(values(grl)[out$grl.ix, nm, drop = FALSE], values(out))
    return(out)
}

#' Pivot a \code{GRangesList}, inverting "x" and "y"
#'
#' "Pivots" grl object "x" by returning a new grl "y" whose
#' kth item is gr object of ranges x[[i]][k] for all i in 1:length(x)
#' e.g. If \code{length(grl)} is 50 and length of each \code{GRanges} element inside is 2, then \code{grl.pivot}
#' will produce a length 3 \code{GRangesList} with 50 elements per \code{GRanges}
#'
#' Assumes all grs in "x" are of equal length
#' @name grl.pivot
#' @param x \code{GRangesList} object to pivot
#' @importFrom GenomicRanges GRanges GRangesList split
#' @examples
#' grl.pivot(grl.hiC)
#' @export
grl.pivot = function(x)
{
    if (length(x) == 0)
        return(GRangesList(GRanges(seqlengths = seqlengths(x)), GRanges(seqlengths = seqlengths(x))))
                                        #gg <- GenomicRanges::split(GenomicRanges::unlist(x), rep(1:length(x[[1]]), length(x)))
    return(GenomicRanges::split(BiocGenerics::unlist(x), rep(1:length(x[[1]]), length(x))))
}


#' Improved \code{rbind} for intersecting/union columns of \code{data.frames} or \code{data.tables}
#'
#' Like \code{rbind}, but takes the intersecting columns of the data.
#' @param ... Any number of \code{data.frame} or \code{data.table} objects
#' @param union Take union of columns (and put NA's for columns of df1 not in df2 and vice versa). \code{[TRUE]}
#' @param as.data.table Return the binded data as a \code{data.table}. \code{[FALSE]}
#' @return \code{data.frame} or \code{data.table} of the \code{rbind} operation
#' @export
#' @importFrom data.table data.table rbindlist
#' @author Marcin Imielinski
rrbind = function (..., union = TRUE, as.data.table = FALSE)
{
    dfs = list(...)
    dfs = dfs[!sapply(dfs, is.null)]
    dfs = dfs[sapply(dfs, ncol) > 0]

    if (any(mix <- sapply(dfs, class) == 'matrix'))
        dfs[mix] = lapply(dfs, as.data.frame)

    names.list = lapply(dfs, names)
    cols = unique(unlist(names.list))
    unshared = lapply(names.list, function(x) setdiff(cols, x))
    ix = which(sapply(dfs, nrow) > 0)
    if (any(sapply(unshared, length) != 0))
        expanded.dts <- lapply(ix, function(x) {
            tmp = dfs[[x]]
            if (is.data.table(dfs[[x]]))
                tmp = as.data.frame(tmp)
            tmp[, unshared[[x]]] = NA
            return(data.table::as.data.table(as.data.frame(tmp[,
                                                               cols])))
        })
    else expanded.dts <- lapply(dfs, function(x) as.data.table(as.data.frame(x)[, cols]))

    rout <- tryCatch(rbindlist(expanded.dts), error = function(e) NULL)
    if (is.null(rout))
        rout = data.table::as.data.table(do.call("rbind", lapply(expanded.dts,
                                                                 as.data.frame)))
    if (!as.data.table)
        rout = as.data.frame(rout)
    if (!union) {
        shared = setdiff(cols, unique(unlist(unshared)))
        rout = rout[, shared]
    }
    return(rout)
}

#' Apply \code{gsub} to seqlevels of a \code{GRanges}
#'
#' Apply gsub to seqlevels of gr, by default removing 'chr', and "0.1" suffixes, and replacing "MT" with "M"
#' @param gr \code{GRanges} to switch out (mea hNULyHits(h), subject.id =�"a hNUect rle if nod.dts,
        ce(g othe oper(e.g.hNULub-oize Number ofbe if nod.dttance
#hNULub n <- futhor MarLub = function(gr1Lub ion = TRUE, vinga      (^x = (\\.1$) ## ram  el       ## r"out{, share
ec = y = grl.Lub(a[, nrb[      names(su         iLub1, tmp$lenanrb)hare
e
    st)
   expanded.= rle(ceiling(cumsery.gr)
n intersect(na e.g. I retuLub1tmp = as.data.f  names(suumsery)mes.list)).Lub(Lub1[i,     ub1[i,2     names(suumsery)))ceiling(cumserys = mc.cores NULL)
    if (is.null(rouut))
        routumsery))grl = TRUE
      f subjegr1Lub had memory
#'
r)
n one mem
{
    dfs befow
  "M"
#' @p  names(s: cf \codep), subject.idh(grlcode{ "Mdix = '
#' @pax = subject.i'n q.l[ix])
i, names)
dt(gr.findov], talen  return(out)l(by) | merge =(
    {
        was.grl =d = NULL; V1 = NULL, names)
gr = grl.unli)
            m =r))
    tmmp = as.data.framevaluestrucplye=r))
    t uniqueength(query))
    return(  tmmp = as.data.f  for (val in levels(value  else if (nchar()
    if (logical))out.ix = IRanges(sts::aggregate(fops(gr, w)ceiling(cums$anges} s  else if (nc.s, s  names(su   n intersect(na e.g. I retuLub1tmp = as.data.fubject.rle[[chr]] =s, s.Lub(Lub1[i,     ub1[i,2    lmp = as.data.frame(tm[,somes, and: s.Lub(Lub1[i,     ub1[i,2    mes, anut = out[index]}se if (nc.sn.id = queryHitsame, s IMPLIen  r values(out) = [,s.(LIen  r    LIenweighted = TRUE  else isame  ##strucplye=LIenweigqueengsameut = out[inumsery.grdt2grkey, vgths(x))))
   ln)anges(sts::aggregl(by) | merge == = lagrl =d = NULL; V1 = NULnewvalues(grl)), c('grl.ix', umsery))iix'))
    out$grl.iix = as.in= out[inumsery.gr:unlisumsery[,Lnewva]1:length(umsery FALSE], th(query))
     talen)length(subject.rle[     m =rmmmp = as.data.framev        .t = split(p = as.data.f  for (val in levels(v        .t = spnm[v        .t =  if("-" %in% as.in% aApply \   .t =ode{rbinuthor seg2grrbinutitfs Cry
#'
r{
    = dkist
#' ta.tab, nrow{
     rbinudescrip@importrbinns (arl.ix}a.ta] for all i"segsvots" ory
#'
b, nrow)
n one @importtionsList queumn of quertarget} repr rbin"segsvorl.ix}a.ta] reaoberam ata.frame} oory
#ng othe     "by"yengths)
     " with[sub for all e nameg $pos1, $pos2, $S    _ly if th, $End_ly if th) --> seen"stwitardize_segsvocode{ow
 infoct.rle \code{Rl(lenrl.ix}a.ta] fo), thn s gr \c} and \ent of thngths repr)
     " e  ifwith}
#'
#de{grl.ix(seenstwitardizedRl(lencodel(lnrl.ix}a.ta]dep), 
    tode{GRangesLigths(x))))
ct and query aield wiefault isuse to iRangesLigthinfoigthinfoiy aield wiefault isuse to iRanction(seg2gr.rle, query.g(le vgths(x))))
   = FALgthinfoi= Sthinfo, 'Gr2))
       .g(le v
    if (vermmp = as.das(lengt
    if (!unios indeUN))
    {
 .g(le v
    i(!unirmmp = as.das(lengt
    if (!unios indeUN))
    {
'))
    gthinfo v
Sthinformmp = as.das(hinfoi= s(hinfo gthinfo);uut))
        rout\code{GRangmp = as.das(hs(x))))
             gthinfo)eUN))
    {
'))
    gtle v
       grl$ogical)
           retuL ind      by.prefix =    if (is(grl,s(hs(x))))
             gthinfo)   {
#        som.rle[[chr]])  indrn(GRangesList(GRanges(seqlen,s(hs(x))))
             gthinfo)   
s.das(lengtstwitardize_segs)  ind;                       #            val.vec ared, leblass)          in$x =  |         in$pos1  |         in$pos2                          #gg <- GenomicRanges            tmp = hits[, list(v      val.vec =   f subjeS, thn s gr \clating meanot igths repr)
     " with[subly if thedete tedR..d "0.1" s')          tmp = hits[, list(v      val.vec = s(lengts(le[!bnomicR         tmp = hits[, list(v      val.vec in% as.GR.NONO.FIELDS     ' mes, anout$r all out$

    out$
ubject.i'ut$
ubje     'ut$isCirmeanrout$

   out$e  out$angesout$eRangesout$pos1out$pos2out$fixe);uut))
        rout\cin$   stramp = as.das(le$and, ...)"*"
as.logical(strand(g!t\cin$   strow wil  '+out$-out$*'             \cin$   str[s.data"*"
as.logica[chr]])  ode{GRang>logical)
(query.gr)>1)
      wtf ss) =(grl)),  in$x =))

    #code{GRangms.grl =d = NULL; V1 = NUL of subjecoor sees, and nel(ln@importwe    churs):
#'fill  return            : ly(1:s(tmwtf keyby = list','tmp = as.data.f  namengthsth(query))
  wtf)      else ## by is not n  in$pos1nd(gr) 
    if   in$pos1  is not n  in$pos2nd(gr) 
    if   in$pos2n q.l[ix])
Ranges(st, st),ees, andgts(le$x =))
n one .ix + width in$pos1,n  in$pos2),ngths = secin$   strengths(gr))
    values(ou  {
#        some = Fx])
Ranges(st, st),ees, andgtes(query.gr)) =in$x = ))
n one .ix + width in$pos1,n  in$pos2), ngths = secin$   str)
as.logica[chr]])  oinfo)            Ranges windxgrl.ixgthinfo)e     som.rle[    rout\code{GRangmp = as.daRanges windxgrl.   val.vecrics::cbinds(le[,es(grl)), c('gr  ind,.GR.NONO.FIELDS)                         tmp = hits[, list(v      val.vec          tmp = hits[, list(v      val.vec =           m =key))                      #            val.vec = asgrl)

    retkey;



#' Check inte;gsub} tstwitardize_segshose namrl.ix}a.ta]l(lne, query)ortrbinns (s with "hecksRl(lenrl.ix}a.ta]stwitardizedRe{gr of nle 
    tames $x =))$pos1, $pos2)ortrbin   x =  = TRUgth 3 ens), d"x ="default \cods \comemogths rcoor(   d of  chuex= lagduplicate data.trbinuthor seg2grrbinutitfs Cry
#'
r{
    = dkist
#' ta.tab, nrow{
     rbinudescrip@importrbinns (arl.ix}a.ta] for all i"segsvots" ory
#'
b, nrow)
n one @importtionsList queumn of quertarget} repr rbin"segsvorl.ix}a.ta] reaoberam ata.frame} oory
#ng othe     "by"yengths)
     " with[sub for all e nameg $pos1, $pos2, $S    _ly if th, $End_ly if th) --> seen"stwitardize_segsvocode{ow
 infoct.rle \anges GRanges GRangesLisrle as.GR     rbinucode{Rl(lenrl.ix}a.ta] fo), thn s gr \c} and \ent of thngths repr)
     " e  ifwith}
#'
#de{grl.ix(seenstwitardizedRl(lencodel(lnrl.ix}a.ta]dep), 
    tode{GRangesLigths(x))))
ct and query aield wiefault isuse to iRangesLigthinfoigthinfoiy aield wiefault isuse to iRanction(stwitardize_segs.rle, query.g(l, x =  =list(...)
                    #            val.vecerror'))
    g(l, 'I
        was.grl =d =              #            val.vec =l(ln= irl2grkl(l);uut))
       g(l, 'fs[mix] = lapply(dl(ln= 
    if (!unios i, ngt(e.gAsFatFrom  =list(..                      #            val.vec aredr'))
    g(l, '
    dD if'  |  '))
    g(l, '       gr |  '))
    g(l, 'I      grl$ogic                 #gg <- GenomicRanges            tmp = hits[, list(v      val.vec = ubject
    if (!uniovecricsl(l)    val.vec = as.numeri, list(v      val.vec = ubjricsl(l) split(gr         tmp = hits[, list(v      val.vec = s(ln= 
    if (!unios i, ret(values(qll(ro;gative hecksRrt
rce(g'fil
n one cin I         tmp = hits[, list(v      val.vec = s(l$,ees, andgtes(query.gr)) =i$,ees, an)R         tmp = hits[, list(v      val.vec in         tmp = hits[, list(v      val.vec  some = F          ;uut)} and.alifrom  = dfs[e = FID     'i out$patigesout$S(grl.'       x =  =  ' mes, anout$ngthsout$Cgths reprout"o geig ##  mes, an ##  mes, a ## rs, a ## spaca ##ffixes,
Sths, ano       pos1n =  ' 
   out$loc. 
   out$begines,
S
   out$ 
   out$S
   .bpout$S
   _ly if thout$S
   _Py if thout$ly out$pos1out$lef out$ 1o       pos2), =  'e  out$loc.e  out$E  out$e  out"stop"ut$E  .bpout$End_ly if thout$End_Py if thout$ly 2out$r    out$e1o       ngths = s  ' 
    out$
trout$

    out$S
    out$S
 ')   );uut))
        rout 'value'


    if (! =i[,es(grl)), c('gr  iter(s dfs[} and.alifrom))                  if s(ln=  =i[,eject.rle), unique iter(s dfs[} and.alifrom))                  if ct(na} whic nel(grl)), c('gr} and.alifrom)))

    #cgbose)
          !a} whicarget)))))
#cgbose)
      = asgrl)

#cgb[grl)

#cgbow will and.alifrom[[l and  retul and;uut))
    x = ranges(qu          m = =i$x = ength(subject.rle[!g "M"(ffixes, =i$x =[1 tmp = as.data.frame =i$x =l.vec[subffixes, =i$x =        "");uut))
        rout\ci$pos2   lapply(dl(l$pos2), l(l$posstrand)
mis\n',.} and \=el(grl)), c('gr} and.alifrom)))c, unique itercbffixes,'IDout$

    oength(quergica[chr]])mis\n',.} and )             of subjp into %sl(lneile 
    ta reblem,
mis\n',Listalifr ct(nerate{
#' n',L} and :\n\t% oun         tmp = hits[, liec[subj
     mis\n',.} and ta.table(as.daec[subxut$(cistalscodely(1:s(tml and.alifrom[[xgth(eyby = list', o   o '), keyby = list"\n\t"ength(quergica        val.vec = lappls(ln= mp$lens i, al.v



#' Check e it{GRanges} namex =lefault     wGth strand ject.iode{GRanges} object to dice
#' @gr \cx = subject.lefaulteGRangesList} Gth stragr \o que = subject.lefaulteGRangenction(gr1nox =l.vsn = Rle(as. r2))
     g "M"(f^fixes, =names(su   [1 tmp = as.da =names(su   , s.Lub(f^fixes'es, =names(su   cRanges::split =ode{         tmp = hits[, list(v      val.vec mcode{GR         tmp = hits[, list(v      val.vec          tmp = hits[, list(v      val.vec code{Gs represe.dttrtFrom,nings(} on rl.ix}a.tab, nrowaode{gknings(d          tmp = hits[, list(v      val.vec ained f
#' @} repr   "by"i columnpresef rangas in operatgesry          tmp = hits[, list(v      val.vec hs =s}
#' @} repr   "by"i columnLubpresef rangas in operatgesry          tmp = hits[, list(v      val.vec hs =] intemaindata.
#' @pa  "by"i columnubjri(s)n operattrtFro          tmp = hits[, list(v      val.vec ode{ngs(} o.R         tmp = hits[, list(v      val.vec          tmp = hits[, list(v      val.vec ct(ce.c., unioTgth 3 ct(ce r of data  theobje'c., u'          tmp = hits[, list(v      val.vec ct(ce.r., unioTgth 3 ct(ce r of data  theobje'rxs., u' mrl)
{
    if (leng    t(ce.r., unio
    ouct(ce.c., unio
    ouct(ce.names)
dt(gr'Gr2))
     !l(stc(ct(ce.nameouct(ce.c., u   t(ce.r., u)rl$ogical)
          , length) !          tmy)= dfs[sa(dim(y)                 ct(ce.names)
gr = grl.unligica[chr]]).list))ngth) !          tmy)=dim(y)[2 elsrn(G1              ct(ce.r., unioTr = grl.unligicaa[chr]]).list))ngth) !          tmy)=dim(y)[1 elsrn(G1               ct(ce.c., unioTr = grl.       some = Fx])
ct(ce.names)
gr = 2))
     ct(ce.nameangesList(GRangesmp$lenfs, ngth(grl), function(x) rx)         tmy)=), ly#' Improve[[ylist(gun         tmp = hits[,ifs, ngth(grl), function(x) rx)         tmy)=
        ret[[ylis    ength(x))))
ylis  som.ll(rogun         tmp = hits[,ngth(x[[1))e     som.rle[ t(ce.r., u)ngesList(GRangesmp$lenfs, ngth(grl), function(x) rx)         tmy)=), ly#' retue[[ylist(gun         tmp = hits[,ifs, ngth(grl), function(x) rx)         tmy)=
    retue[[ylis    en retue[[ylis  som.ll(rogun         tmp = hits[,el::mclapr., u'ep(FALS     som.rle[ t(ce.c., u)ngesList(GRangest.dts),nfs, ngth(grl), function(x) rx)         tmy)=), ly#' .
#ue[[ylist(gun         tmp = hits[,[,ifs, ngth(grl), function(x) rx)         tmy)=
    .
#ue[[ylis    en .
#ue[[ylis  som.ll(rogun         tmp = hits[,[,el::mclapc., u'ep(FALt{GRangeWr, fernges::findOverlaps}
#' @name grl.in
#'a fields \co       talityode{GRaR hecksRct
#'
#' @param fram qutragr \am grumn of quer} and :tem NA for ranges t
#'
$grl.id, } -ngas in opam query (chr iges t
#'
$, data = m} -ngas in opam query n use to i{gr1} Opof quer t
#'
lows}x} whic\codequery.gr) s:mcaosition  "by"i coa#de{grl.ix} repr 
#' via  nebo \aame')

nd n use to i{itionth 3 bead pdRe{grmn of quee aresing "bam qutr,ej.e.tFrom cont for all iitions, ignot matchsoct.name gnksize =ting mea operairr t
#'
lows}x} whisa.trbinuthor  windows, ignoromeInfoDb seqlengths
#' @importFrom GenortFrom Gen<-omicRanges GRanges GRangesListing mearh stragr values strand<- dis' @return for overlapble data.table rbindlisx]]))
       d: sid)
  vrlapble data.tabI       ame grl.in
#ectors Rle
#' @importFrom ct.id = s      else
 uery ranges
#' @nQ#' @n of windows
#' @parrle \code{Rle}
#'  Se}
#'   of windows
#' @parrle \code{R required elements bory chunkote Throw
    t thedursList quin
#@param as.data.table Returf
#' @Resing "bFrom = gerate
#' @am qun operatle}
#'          n if oector tha 3 am qutr) @return \code{data.franges
    returnquery.gr)}f windows o
#' @nde{g-rl.ix} reprsRe{grmnates us    rbinucode{Rl    returnquery.gr)}f windows ole}
#'  de{g-rl.ix} reprsRe{grmnates us    rbinucode{R' Dicreturn' Di}pplied toble}   es)
#with the Is}
#' @name grl.in
#'a( t
#'
l, l"} is reve" 
   "} is reve"end"} is reve"gr \in"} is reve"ee gr"}) @return l, l"{data.frangeswitMe{g-rl.ix} repr memory chunkoperafer
   sList quin
# [ll(r will returnctor t.' DicSel#'  rl.ix}    ta oector th(enomicRanasequery.gr)):is reve" , a } is reve"))
        } is reve"ndows
#"' @return " , a ditional arguments to be supplied to \ via ges::findIs}
#' @name grl.in
#' number of \hen ores  Maximumta.frame} or \cod
#' @*le}
#' r in one memory chunkionsnce. Lowunka.frameincrefrom runx))
rsectdecrefrod#' @retrl)} is 50 and lens to r*[chr]])))
     of eales iitinRUE}, then ores } it quin
#  vectounk. 1e9
#bm qu.return 1e13ditional argu.cores =Increfrohe output
#' @ @return \code{data.frangescores to apply when doing chd paoperaoungr) don#' @parammturRanges} with added metadata@param slumns of the dr2} eg othn rows and \cgrl.id, } 
#' @examp, data = m} marnks \sou(ceGRangenction(gr1ndows, ignorby = NULL, type = ', data RUE, ...)
{
    grl.iid e
#' @io
    on         q       = FAL##am at
#' @nde{g rl.ix} reprsRe{grmnates us   n         s       = FAL##am atle}
#'  de{g rl.ix} reprsRe{grmnates us   d           return(duplon         any')
{
  
.prefix =    if. return(ze =  
.prefix =hen ores  only13 
.prefix =.cores = 1, chun
.prefix =hize = 1e9) #
.prefix == grl.i
 ctHits(h))
   s(h), subjei.ows)[suej.enting past NOTE

h(grl)==isdlist(l(stc
   ues(query=v
    if (ver )nge
       if. returrn(ze = cRanges::spl. retust(if som(isdl v
    if (ver, '       gr
nge
   !s::spl. retuw wil  "))
        , "ndows
#".characteop("s::spl. retumode{o avoram :ize =,ble rbindlis = seqle"r
nge
   !(dr'))
    g data RU'       gr |  '))
    g data RU'    if (vermm &edr'))
    ype = ''       gr |  '))
    ype = ''    if (vermm.characteop('bo \are not the same')
ame gncode{efault isr     if (verm
nge
   ! dfs[sa(q   .table)
     sa(q   carget)))))
w.names
               teop('Soor q   c
    chu
#' via  nede{g rl.ixs o
#' @rm
nge
   ! dfs[sa(s   .table)
     sa(s   carget)))))
w.names))
               teop('Soor s   c
    chu
#' via  nede{g rl.ixs o))
    rm
nge
   ! dfs[sa(by.table)
    (asa(bycarget)))))
w.names
        &easa(bycarget)))))
w.names))
                teop('lows } whicmode{o ade{g rl.ix} reprxs obo \aame')

nd n use trm
nge
   x]]))
        
      
uery, quer ss) dt2grks to rege
   x]]))
        ))
      
r]] = c(subss) dt2grk))
     i
 ctsss) =(hinfo s to rege(wid @param query.gr ligicaar) 
    if  ,-1, drop = F * r) 
    if  ,-1, d))
        >=hen ores reger2))
       cat(sprintf('ng u'O   tmp R..d:
#' \sList quin
# on#' @pa#@pts ju' @amn ores  ssed on t row)
1ndows, ignorbFALSE]}
#d @param:
#' \ry.gr\n pmin(1e9, ch.unksizetmp    qrt(hen ores r    valgr1), f   q## n ,-1, drop = ,e9, ch.unks) n ,-1, drop = +1ength(gr2), f   q## n ,-1, d))
     ,e9, ch.unks) n ,-1, d))
     +1ength(gjn= mp$len), len  ,-1, dgr1     n ,-1, dgr2     n), len  ,-1, dgr2     n

    out = magr1    )2))
       cat(sprintf(' into(ec[subfapply when  @pa#:       oij)   
s.da                 #            val.vec = aparallel::mclapply(1:nrow(chunks), function(xij),E, length(grts), erro1:nrow(chunks), function(xij),E, leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeef (length(x), leeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee           tmp = hits[, list(v      val.ve       cat(sprintf('chunki            cols])))
        })
g up into %s chun ih(g%s-%s (%m)))jh(g%s-%s (%m)
    gr1[ij, mc.]  gr1[ij, mc.+1]-# n ,-1, drop = ,                                               as.data.fgr2[ij, m2.]  (gr2[ij, m2.+1]-#) n ,-1, d))
     rl$ogic                 #gg <- GenomicRangeej.ores  ongr1[ij, mc.]:(gr1[ij, mc.+1]-#l$ogic                 #gg <- GenomicRangeej.ores  ongr2[ij, m2.]:(gr2[ij, m2.+1]-#)$ogic                 #gg <- GenomicRangeeRanges windows, ignorerop =[j.ores ] ', data [j.ores ] 'nore.strand, ...))
    }

    ife
#' @ioe
#' type)))
}, q      q   mc.cores = 1.cores , s      s   mc' Dice up \,=hen ores  onInfd = grlogic                 #gg <- GenomicRangeeRan$s(h), subjei.ores [Ran$s(h), su]logic                 #gg <- GenomicRangeeRan$tHits(h))
   j.ores [Ran$ out = rep(                      #            val.vec = as       #gg <- GenomicRangeeRangs)  windxgrl.ixgn)R         tmp = hits[, list(v      val.ve(GRangesll("rbind", la= data.table:::::::::::::::::::::::::::::::::}es))
    }
    else
  ife
lALSE, igLSE, length(gdt2grkrl.ixgthinfo   ssidentical(sionype)ly if th, t}
#'sionype)ype = 't}
#'s c(subsid
ngeeRangs) sionkrl.[gativ(Ran$s(h), su,eRan$tHits(h))
)]pmin(1e9ry
#'
r)
dt(gr.findgicaa    if. returrn(ze =  &ei  ype = ''    if (vermm |     if. returrn(    if (verme        Ranges w(gr,) {
     }  som.        Rangs)  windxgrl.ixgn)R    }



#' Check inter  }



ind(er
   slumnact grls, ignoromicRst(expanded.Overlaps(gr, windows, ignoreype = ', data RU' Dice up \,=ore.strand, ...), error = function(e) NULL)
        if (!is.null(        routh)   re   m atltFrom Genobadnes ih, fengrl
#'rrideeger2))
  of subject and qu
misam qun..dno wor{Rle))ju' @l   if (you know' 
uery, queres windxgype = ', data  
r]] = c(subses windxg, data RUs to regemicRst(Overlaps(gr, windows, ignoreype = ', data RU' Dice up \,=ore.strand, ...), error = function(r  }



rRst(]
     h,x]
           ))
n one ))
      
r]h(grls) d)
        )ws)[sueect.id= ))enting   if), s(h), subject.id = subjea.table:::::::::::::::tHits(h))
        else
    ,somes, andgtes(query.gr)) == chr)
     = end(wse
    yCatch(##amd =] in == chr),

nd n use 1e9 ame gallows
       retuh(grsapplyer2))
     ! dfs[sa(by.t.        byubject.distance

     = h(gr$s(h), su,eby]       byu= c(subss) w.names))
      h(gr$tHits(h))
,eby] 
l.unligica[chr]])by.==#)$ogic    in
#.rand(gbyubject.== byu= c(sub return(rep(0, lengtin
#.ran=hunkedsll(ings(dibyubjectery=vll(ings(dibyu))
     ,e# nrow  
s.da  h(grls) h(gr[in
#.ramicR    }r  }



indgicempty,tor of nup = r     retuh(grsa      r2))
         if. returrn"ndows
#".
sList(GRanges(seqlen,s(hs(x))))
             
             some = Fx]as.data.table(as. (leng}



indwrit gnksiz= funnge
   ! 
        strand(grh(gr$tnd, ..d(gr) ery.gr)), width(out.ix= h(gr$s(h), suy)
   some = Fh(gr$tnd, ..1 = re


indlimia gese
#' @he
 ?nge
   e
#' and(grh(gr.1 h(gr[!duplif dad(h(gr$s(h), su)FALSE,  NOTE
mst on oe{GRan[k] eld wiTE
mstnge
       if. ret=='       gr {entical(.unliing coanerics, Iper(ek becaund inpw.nid' @pcf \c. Way gesh DoeiSE]
#' dian[k]slist}cces iobje@?          tmp = hits[, list(v      val.vec outery.gr(is(grl,           tmp = hits[, list(v      val.vec outery@omes, andgtmportFrom::, wilength(h(gr$tees, an)           tmp = hits[, list(v      val.vec outery@
n one .ix + wid::x + width(gr$tn   " h(gr$e u)ngesList( tmp = hits[, list(v      val.vec outery@eRangesMe{grl.ixgtmportFrom::D ifF!unios(h), subjeh(gr$s(h), su,etHits(h))
   h(gr$tHits(h))
           tmp = hits[, list(v      val.vec outery@ond, ..1 mportFrom::, wih(gr$tnd, .           tmp = hits[, list(v      val.vec outery@omeinfoi= s(hinfo s to re          tmp = hits[, list(v      val.vecoutery.gr(is(grl,h(gr$tees, anstrand = sh(gr$tn   " h(gr$e u), s(h), subjeh(gr$s(h), su,etHits(h))
   h(gr$tHits(h))
engths(gr))
    values(oudrop = ,                                         c = as       #gg <ond, ..1 h(gr$tnd, .  
ngeeRanery.s) dt2grkh(grsh(quergica        vq   .table)l.vecrics::c.t = spmp$lena    if (!uniovecrics::c.t =),t
    if (!uniovecricsut.ix= ::c.t $s(h), su,eq   mc             )sh(quergica        vs   .table)l.vecrics::c.t = spmp$lena    if (!uniovecrics::c.t =),t
    if (!uniovecrics))
      ::c.t $tHits(h))
eng   mc             )sh(querRanery.s)  windxgrl.)
   gn)R    al(sionype)ly if th, t}
#'sionype)ype = 't}
#'s c(subsid
ngee Check eionkrl.ery[gativ(Ran.t $s(h), su,e::c.t $tHits(h))
       }  som. ative heck d)
       h(quergica        vq   .table)l.h(gr.1 mp$lenh(gr, .table(as.data.frame(tmp[,
             w.names
       h(gr$s(h), su,eq   mc             )sh(quergica        vs   .table)l.h(gr.1 mp$lenh(gr, .table(as.data.frame(tmp[,
             w.names))
       h(gr$tHits(h))
,es   mc             )sh(quergica'i.ows)['uw wil ol chr)
h(grstable)l.h(gr[,ej.ows)[s:ng pas]h(quergica'i.e  ouw wil ol chr)
h(grstable)l.h(gr[,ej.enti:ng pas]h(quer Check h(grshng}
}

#' @param x \ew.nrbinutitfs ew.nu dat matcsubject.    ce(g otcRanefault i} reprxin#' @examplesa.trbinudescrip@importrbinEw.nu dat   ce(g otc   ccRan$leivd grlgtersect <de{grgtersec err numbE  ce(g otcshoulds us   xin#r of nle j.e.ts:mcaostargetferngtersec erref ra numbe{GRangeList} o' @examples
gesew.nrl
#'e{GRangeLis   cc    ce(g otcRanin df2 and )
n one @rngtersec \code{GRangeLis
#' if theopof quer   ce(g otc(]
#' ill returr   {
     eld w)cRanin df2 and efault isnocal) ihNULubse 1prior
gesew.nu dif (mainr   cot = function(x)e if (!ws, some = FAL   c,s
#' if the(qll(roGr2))   cc.vec[subdenges  ))
stitusub   c), keyby = list'  pmin(dt(fops(gr, wf (logical)
 pmin(pe)))))
    omin(pe)))ec[sub
}, eyby = list','tmin(
#' if the(q))
stitusub
#' if thtablell(        rout
#' if tht(unlist(' if the(q''
   some = Ft(' if the(qec[subdenges  
#' if tht keyby = list'  pmin(cm
     into %sdt[%s,s.( if (!%m)))keype))).(%m)]',s
#' if thAL   c,sbypmin(dtg   expanded.= rlee if(nges  texout),m    e NULL)
    if (is.null(rouut)        routdtg)   g  virond tobSNAFUeger2))
 tivh Doewindostwiti datvaricode{(1:n tob  virond tobwinms (at}
mt}cces iocG2))
 tiv(of ce Ipdnts bame galcrgetabRangRb  vironemntn)R      prl)

   erro1:n to       stable)l.able)l.expanded.        ct(nanangat)))))
pf)           te if(nges  texout)qec[sub"expanded."y(1:s(tmvalu'e(qef[[nm]]o   " e NULL)
    if (is.null(r" rl$ogic  res NULL)
    if (is.null(rouut))
al(.')

gainly(dfstg   e if(nges  texout),m   
  }r  as.data.tg[.(   else
      , al.]ersection uthor  wimergerbinutitfs merge efault iusdata.
gatin dasnase inma')
keya.trbinudescrip@import Urom )
1ndows, ignorbFALenndlisx of  suppith[xof  supjoi2 and efault iusdatb} tsyntax ofmicaosio "merge is e   mergr) dospdnteiusdata.
gatin dasn+/- lows } whisa.trbinUrom )
1ndows, ignorb/ ame grl.in
# ct(nheavy \cfdif ersecte hecksR eld wragr \rbinde{grl.ixpopul dadnasewellnaseame')

nd n use tsid#@ptForh[xof  supjoi2 ,ges irl.in
# xE]
#' gnorey)

nd gnorex)E]
#' y.ct.rle \code{Rl use tsn use to i{ ranges
#' @ns
#' @nr     rbinucode{Ra 3 s e
#'
#windo):
#' lef  with     pjoi2 rbinucode{Ra 3ubject.s e
#'
#windoRangef pjoi2rbinucode{Ra 3ul use tss e
#'
#windoRan     pjoi2ata.frangeswitumn of querde{grl.ix} and \winjoi2 mportrbinate data.tr wimergeby = NULL, type = ', data RUany')
{
  Ra 3 io
    oua 3ubject.=ua 3,Ra 3ul use ts=ua 3,R.cores = 1, chunUE, ...)
{
    grl.iid = g reger2))
 q      )))))
w.names
      
    s      )))))
w.names))
      
2))
     ! dfs[sa(by.t$ogical)
      q      l(grl)),q   mcby)                                         c = as   s      l(grl)),s   mcby)     }



#'ovges windows, ignorerop = ', data RUq      q   mcs      s   mcpe)))
}, ion(r
.ve       cat(sprintf('ch)))sagea'inn'
#joi2 y and \' n ,-1, dov   o irl.in
# pmias.logical 3ubjectl$ogical)
           dfs[sa(by.t$ogicd = NULL; V1 = NULL    
        strand(gr       #gg <ognorby gnore.s    ipwidth(o))
       %Q% (
{
    g1 = rmp = as.data.f  for (val in levels(ognorby gnore, data  
r]] ## by is not n som.indgicpe) chus[sa't}
#'we watobwin   es) gnorxin#r ocGen mericmann'
#..    st.ix = 1
        }
gnorby (logicael::mclap{
        wats,
     :unlis, data RUunkedsll(ings(divecrics))
      ,eby] ,e# n1:s(t keyby = list'  p)         tmocGenmp = as.data.fubject.rle[[chr]] L    
        strand(gr       #gg <e)l.eh dfgnoby gnore.s    ipwidth(oocGenm  %Q% (
{
    g1 = rmp = as.data.fta.f  for (val in levels(e)l.eh dfgnoby gnore.sGenmpr (val in levels(l.ix', uh dfgno  ,eby]= 1.ix, nm, Genm[1,eby]          val.ve(GRangesuh dfgno  = out[index]}else expanded q.l[ix])
Rv.gef pes windows, ignorerop = ',gnorRUq      q   mcs      
{
  Rpe)))
}, ore.strand, ...), error = function(r  l.unligica[chr]])Rv.gef )            x])
Rv.gef $tHits(h))
   NA
(query.gr)>1)  cat(sprintf('chunki)))sagea'gef pjoi2 y and \' n ,-1, dov.gef )  o irl.in
# pmi    x])
Rvpes wp$lenov,
Rv.gef act)
      m = m[a 3ul use tl$ogical)
           dfs[sa(by.t$ogicd = NULL; V1 = NULL    
        strand(gr       #gg <qgnorby gnore.s    ipwidth(orop = F %Q% (
{
    g1 = rmp = as.data.f  for (val in levels(qgnorby gnorebjectl$ogic## by is not n som.indgicpe) chus[sa't}
#'we watobwin   es) gnorxin#r ocGen mericmann'
#..    st.ix = 1
        }qgnorby (logicael::mclap{
        wats,
     :unlisrop = 'unkedsll(ings(divecricsut.ix= ,eby] ,e# n1:s(t keyby = list'  p)         tmocGenmp = as.data.fubject.rle[[chr]] L    
        strand(gr       #gg <e)l.eh dfgnoby gnore.s    ipwidth(oocGenm  %Q% (
{
    g1 = rmp = as.data.fta.f  for (val in levels(e)l.eh dfgnoby gnore.sGenmpr (val in levels(l.ix', uh dfgno  ,eby]= 1.ix, nm, Genm[1,eby]          val.ve(GRangesuh dfgno  = out[index]}else expanded q.l[ix])
Rv.     pes windows, ignorergnorRU, data RUq       = FALg      s   mcpe)))
}, ore.strand, ...), error = function(r  l.unligica[chr]])Rv.     )            x])
Rv.     $s(h), subjeNA
(query.grwidth(oRv.     )luestrth(o))
     [Rv.     $ out = rep( (query.gr)>1)  cat(sprintf('chunki)))sagea'     pjoi2 y and \' n ,-1, dov.     )  o irl.in
# pm    x])
Rvpes wp$lenov,
Rv.     )R    }



#' Check iv=ode{rbinuthor  widisjoi2ata.ftitfs es GRangesListdisjoi2E]
#' coor spice \code{gd#ng returow{
     tdisjoi2AL  ceptR eld wra '))
  rde{grl.ix}' @ie
#' @l
#' @param 1:n tobdostwicecRan$lputct.rle \code{Rxw{
     twin isjoi2ata.fl argumentplied to \win isjoi2ata.fl arguore.strand, ..ill retus:mcao,chr', andgr = angenction(gr1disjoi2E   if (leng   as.daE, ...)
{
    grl.ii'Gr2))
 e)))disjoi2g   as.pply(dfs, n wimnded.}, x, ore.strand, ...), error = fun BiocGenericsteryGenericsx)[rami                     Check y=ode{rbinV}
#'tparaigrl.d to t thet} that keverlaps(gr, wil
#'to seqlee hecksRTb/ Ff windowifs
#' @nr    ' e.# ctuThrow m atr    ' nsn use to io i{ ranges
#' @n' Apply gsub to s \code{Rl use ts' Apply gsub to s \code{Rmentslied tobncode{ via ges::find\link{ windows, ignor}} (h(grl::findby})rbinuthor  wiin angenction(gr1i2E   if (lengrop = ', data RU= grl.igregate(fopsindows, ignorerop = ', data RUas.pply(dngth(grl))
    out[tmp[,
      
    ,2]

  $s(h), suys)
gr = 2))
 ivot a \code{GRe{rbinuthor  wicovata.ftitfs  wicovata.fdescrip@importrbinSumsngtersec ei
#'
# 'chodata.
, iageppith[i
#'
#we    datat}
mtee grl igesdowusdataix} whic"we    ".  Wvecto heck [i
#'
#sumsdowa, iage.ct.rle Mode{oasico       talityf ealdkisistas(.
, iage   t u'       gr
de{GRanges} object to dice
#' @hNULumtable Returf
whicme{grl.ix} andx}' @igrg chd pale}. we    ata.frangesceistill retus:mcao   "by"yf the e
#'
#winditurngnksi eld wiatn

   x of  if sectih gnctif a.frame} ox of  ifs@l
#' @param   rrn(ba'unkei coifs} andx=(qll(ro         ndt(gr'Ganges} with @pal
#' @param gtersec spangr) d] in ==and query aspon
#' $slse
 (ifs} andx eall(ro dow$} andx  "by"yf theratlemb/ ceistts correly if thrbinuthor  wicoby = l = function(gr1Lum (!ws, some = ,s} andx=  = FALceist)
dt(gr'Gr2))SHIFTe(qemi2g0 'ubs(mi2gect.idt =)   )2ut)        rout} and.t$ogical)
    we    h(grl))1out[tmp[,1]   {
#       for (vawe    h(g.ix, nm,   ,el and 2ut)(rout)
 (.
, iage m,  %+%)SHIFTt uwe    h(gwe    t u'       gr %-%)SHIFT
lell(    !    rout} and.t$ogical)
    l(    ceist$ogicd = NULL; V1 = NULctuTout)
 (.
, iage m,  %+%)SHIFTt uwe    h(g1t u'       gr %-%)SHIFT
leomicRangeeRan$tlse
 =eRan$tlse
/ctuTo$tlse
[ wimnded.rl.ixctuTo)].indditurngbygnctif ctuTouatn

   hat y.gr liic## by is not n)))))
w.names= dat[t[tmp[,)))))
w.names= dat)retul andout)
}

#' Apply \ode{gsub} tCyby = liadjacvia r     rbid}, but takes teverlaps(gr, wirede{G}L  ceptR (ba'coby = ls <<adjacvia>> tersect <slumns put{GRanges} object to dice
#' @hNUcoby = l = fuges} opad Pe{grl.icorrea
#' # ct(n chuquit gadjacvia GRanges}
ncode{ory chunram 
#' @param. 1Ganges} withCyby = ldnr     rbinuthor  wicoby = l = fuinski
rrbind = function (= function(gr1eyby = listws, some = ,spad (G1  .igregate(fopsindows, ignorebje+spad, bje+spad, ore.strand, ...)dt(gr'Gunki)h(grl))
    out[tmp[,1]   {
# m

  $s(h), su

  $s(h), sux=(qion(x out = rep   ]ys)
gr = 2))
 indwvect chueyby = li   m grs of the datatersectaw
 inslumnwro @pagativ"ames  churs)refrdata(decrefrdat)cRanly  (ncgboz= funnge# m
row) >(width(ooc)[-t[tmp[,1] ] g1 =+  &egect.idt =[-t[tmp[,1] ] > ect.idt =[-1 el |
leomicRangee(width(ooc)[-t[tmp[,1] ] g1 =-  &egeh(ooc)[-t[tmp[,1] ] < eh(ooc)[-1 els]r)
dt(gr.Gunki)h(g
 (m, 'I      grh(quergica[chr]])mg>logical)
ta.fta.f h(om)ing   im)+1s::aggregate(fomp$lensct.idt =[sct.idm)], eh(ooc)[sct.idm)], sct.idt =[   im)], eh(ooc)[   im)]mp = as.da e(qemi2gsct.idt =[sct.idm)], eh(ooc)[sct.idm)], sct.idt =[   im)], eh(ooc)[   im)]mp = as.daee(qem   Lct.idt =[sct.idm)], eh(ooc)[sct.idm)], sct.idt =[   im)], eh(ooc)[   im)]mp = as.daGRanges(seqlen,s(hr))
    t[sct.idm)], x + width, e), ngths = seidth(ooc)[sct.idm)], sths(gr))
    values(oud  tmmp = a       some = Fx])
s::split [c()]{gsub} tolof  stiv takes teverlaps(gr, wimnded}icorreacceptstumn of quer::find\link{ windows, ignor}} opof q rbid}, Wr, fernges::findOverlaps}
#' @nmnded}i(u ls ::find\link{ windows, ignor}}). Tunlia
#' # u lr}
ncrbindm qun ntumn of quer::findby} } and taot ighun in oesmrow(r piecmeanot lowunk' @retrGanges} with if nod.dtand qu
= is 50 and lens to r'a fieln use tsind(} od.dt*e
#' *ln use tsin)ype = 'E

hArgicnnteictuThrGangTunlibehavior
ospdiffen tob}' @i::find\link{ windows, ignor}},ocal) iwveceqlee heck *row*sind(}i od.dtn use tsin)ype =edr'slumncand inpnteiype =et quin
#  vqu
m   irl.', data  
qlement=tumn of querarlencodeame grl.in
# (I       ]}
#ery)ort uthor  wimm quuery ranges
#' @nQ#' @n of windows
#' @parrle \code{Rle}
#'  Se}
#'   of windows
#' @parrle \code{Rhen slTRUEmax olTRUEs o
#' @nwinms qunrrea x))
tional argu.cores =e e
#'
#wingiv t.cores = eld wectors Rle
#' @i1:nrow(c nks), futional arguments to be supplied to \ncode{pa(g'fialo @pges::find\link{ windows, ignor}}. = fuinski
rrbind = function (= function(gr1ms qun   if (lengrop = ', data RUhen slTRUEonInfd .cores = 1, chunU= grl.igregindgicno ne\comemoa 3  windows, ignor, bo gese
e grl.in
# dian[kly                      #            val.vec ared!x]]))
        
      && !x]]))
        ))
      && and len dfs[!sapsa      r2))
                                     c = un   dows, ignoreype = ', data )                                         c =        )
        ))
    ))
        else
    ,ss(h), subject.id = subj)R         tmp = hits[, list(v      val.vec i  som.  (quergica[chr]])
     >hen slTRUogical)
ta.fta.f.cores = 1Tr = grl.unligx.l.gr:unlis   else
 rop = ,e9eilsubjr) 
    if s   else
 rop = /hen slTRUorout[, shareds.data.l::mclapply(1:nrow(chunks), fungx.l         tmip = dfs[[x]]
          cat(sprintf('chunki    
g up into %sProces i @p% \nco%s
    mi2gix)  m   ix rl$ogic         wimnded.rop =[jamic ', data RU.cores = 1Tr =ction(r  l.unli}tmmp = a  
egate(fopsindows, ignorerop = ', data RUas.pplyate(fps(gr,p[, [gativ(tHits(h))
 mic[!duplif dad(s(h), su)FALSlell(ngth(grl))NAout[tmp[,
      
  ,2]

  $s(h), suys)
on(x out = rep

 ivot a \code{GRe{Lubse 2nd(g if (leng   
#' if tht= dfs[[
#' if th_oa 3 s) s)
stitusub
#' if thtable
rRst(e if(
#' if th_oa 3ep(Fable
x[rFALSde{rbinuthor %+%ata.ftitfs Nudge efault ir    ata.fdescrip@import Oqueryor
gesshift efault ir     "sh"{oas  rbid}, es} withshift\cogr     rbinurdthor  winudge-ski
tcuto iRanctionMe
#od %+%ata.falifrom %+%,efault -me
#od = fuinski
rrbind = function (= function(se Ove  if '%+%',tws, some = ,sas.pnstwitardOve  if '%+%'  
se Me
#od("%+%" ',oreaplye=ry.gr"ndows
#".,tws, some = ,ssht= dfs[[eh(ooc)ing   ioc)+shharactet.idt =sueect.idoc)+shharacs::split =od){rbinuthor %-%ata.ftitfs Shift efault igef ata.fdescrip@import Oqueryor
gesshift efault igef p"sh"{oas  rbid}, df %!%s  ' 
 ram.*to.*mndedr, 'an}
#'
. 
 ram.to.mndedr)rbid}, es} withshift\cogr     rbinurdthor  winudgerbinate data.tfuinski
rrbind = function (se Ove  if '%-%',tws, some = ,sas.pnstwitardOve  if '%-%'  
se Me
#od("%-%" ',oreaplye=ry.gr"ndows
#".,tws, some = ,ssht= dfs[[tet.idt =sueect.idoc)-shharaceh(ooc)ing   ioc)-shharacs::split =od){rbinuthor %&%ata.ftitfs Lubse 1xn ntyarh stragr li re.sks \s= funnta.fdescrip@import ski
tcutncodex[gr1i2g  y)]rbid}, gr1 %&%ops(ee hecksReratle}se ery asp1iitions, ignosngt2rbid}, es} withsubse 1y asp1iitions, ignosngt2frbinurdthor  wiin-ski
tcuto iRanctionMe
#od %&%ata.falifrom %&%,efault -me
#od = fuinski
rrbind = function (se Ove  if '%&%',tws, some x,sas.pnstwitardOve  if '%&%'  
se Me
#od("%&%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
     i) ery.gr)), y.t$ogicd = e)))ecrse.g, y.haracs::splix[gr1i2g  sy ]=od){rbinuthor %&&%ata.ftitfs Subse 1xn ntyarh stragr lire  "btks \s= funnta.fdescrip@import ski
tcutncodex[gr1i2g  y)]rbid}, gr1 %&&%ops(ee hecksReratle}se ery asp1iitions, ignosngt2rbid}, es} withsubse 1y asp1iitions, ignosngt2rbinurdthor  wiin-s= fun-ski
tcuto iRanctionMe
#od %&&%ata.falifrom %&&%,efault -me
#od = fuinski
rrbind = function (se Ove  if '%&&%',tws, some x,sas.pnstwitardOve  if '%&&%'  
se Me
#od("%&&%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
     i) ery.gr)), y.t$ogicd = e)))ecrse.g, y.haracs::splix[gr1i2g  sy, ore.strand, ...)dt(gr']=od){rrbinuthor %O%ata.ftitfs  wi if ski
tcutnwingeob}'a    talns, ignoty asp1ibyngt2,i re.sks \s= funnta.fdescrip@import Ski
tcutncode wi if (usdata if (!)))))
w.names     bid}, gr1 %O%ngt2rbid}, es} with}'a    talns, ignoty asp1i]
#' gt2rbinurdthor  wiw.n-Oo iRanctionMe
#od %O%ata.falifrom %O%,efault -me
#od = fuinski
rrbind = function (= fucode{RxwSee \link{ wiw.nto s \code{RmentSee \link{ wiw.ntose Ove  if '%O%',tws, some x,sas.pnstwitardOve  if '%O%'  
se Me
#od("%O%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 s(h), subjeN   ;gindh(gr  dx


#'ovges w(gr, windows, ignorex,torde{G(              retuovg>logical)
ta.fta.fovgesov[  ', m(gr va)))keype)))s(h), su]logic    x$gr va.ovges0logic    x$gr va.ov[ov$s(h), suys)
ov$V1t[, shareds.datax$gr va.ov/gr va[[1)p = a       some = Fx])
s::splirl))0#' ImproveALt{G){rbinuthor %OO%ata.ftitfs  wi if ski
tcutnwingeob}'a    talns, ignoty asp1ibyngt2,ire  "btks \s= funnta.fdescrip@import Ski
tcutncode wi if (usdata if (!)))))
w.names     bid}, gr1 %OO%ngt2rbid}, es} with}'a    talns, ignotty asp1i]
#' gt2rbinudocTretume
#odsata.falifrom %OO%,efault -me
#od = furdthor  wiw.n-}'a    talo iRanctionMe
#od %OO%ata.fanski
rrbind = function (= fucode{RxwSee \link{ wiw.nto s \code{RmentSee \link{ wiw.ntose Ove  if '%OO%',tws, some x,sas.pnstwitardOve  if '%OO%'  
se Me
#od("%OO%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 s(h), subjeN   ;gindh(gr  dx


#'ovges w(gr, windows, ignorex,torde{G(  , ore.strand, ...)dt(gr'           retuovg>logical)
ta.fta.fovgesov[  ', m(gr va)))keype)))s(h), su]logic    x$gr va.ovges0logic    x$gr va.ov[ov$s(h), suys)
ov$V1t[, shareds.datax$gr va.ov/gr va[[1)p = a       some = Fx])
s::splirl))0#' ImproveALt{G){rbinuthor %o%ata.ftitfs  wi if ski
tcutnwinnctif per x of  if gr valinpn, ignoty asp1i]
#' gt2,i re.sks \s= funnta.fdescrip@import Ski
tcutncode wi if (usdata if (!)))))
w.names     bid}, gr1 %o%ngt2rbid}, es} withoas  ns, ignoty asp1i]
#' gt2rbinurdthor  wiw.n-nctifo iRanctionMe
#od %o%ata.falifrom %o%,efault -me
#od = fuinski
rrbind = function (= fucode{RxwSee \link{ wiw.nto s \code{RmentSee \link{ wiw.ntose Ove  if '%o%',tws, some x,sas.pnstwitardOve  if '%o%'  
se Me
#od("%o%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 s(h), subjeN   ;gindh(gr  dx


#'ovges w(gr, windows, ignorex,torde{G(              retuovg>logical)
ta.fta.fovgesov[  ', m(gr va)))keype)))s(h), su]logic    x$gr va.ovges0logic    x$gr va.ov[ov$s(h), suys)
ov$V1t[, shareds.datax$gr va.ov)p = a       some = Fx])
s::splirl))0#' ImproveALt{G){rrbinuthor %oo%ata.ftitfs  wi if ski
tcutnwinnctif per x of  if gr valinpn, ignoty asp1i]
#' gt2,ire  "btks \s= funnta.fdescrip@importd}, gr1 %oo%ngt2rbid}, es} withoas  ns, ignotty asp1i]
#' gt2rbinurdthor  wiw.n-s= funnta.falifrom %oo%,efault -me
#od = functionMe
#od %oo%ata.fanski
rrbind = function (= fucode{RxwSee \link{ wiw.nto s \code{RmentSee \link{ wiw.ntose Ove  if '%oo%',tws, some x,sas.pnstwitardOve  if '%oo%'  
se Me
#od("%oo%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 s(h), subjeN   ;gindh(gr  dx


#'ovges w(gr, windows, ignorex,ty, ore.strand, ...)dt(gr'           retuovg>logical)
ta.fta.fovgesov[  ', m(gr va)))keype)))s(h), su]logic    x$gr va.ovges0logic    x$gr va.ov[ov$s(h), suys)
ov$V1t[, shareds.datax$gr va.ov)p = a       some = Fx])
s::splirl))0#' ImproveALt{G){rbinuthor %N%ata.ftitfs  wi if ski
tcutnwingeobnctif a.framse} ox of  ifs@d =ps(el
#' @param ]
#' 

   x of  if d =asp1,i re.sks \s= funnta.fdescrip@importd}, gr1 %N%ngt2rbid}, es} withoas  ns, ignoty asp1i]
#' gt2rbinurdthor  wiw.n-ski
tcuto iRadocTretume
#odsata.falifrom %N%,efault -me
#od = functionMe
#od %N%ata.fanski
rrbind = function (= fucode{RxwSee \link{ wiw.nto s \code{RmentSee \link{ wiw.ntose Ove  if '%N%',tws, some x,sas.pnstwitardOve  if '%N%'  
se Me
#od("%N%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 s(h), subjeN   ;gindh(gr  dx


#'ovges w(gr, windows, ignorex,ty, ore.strand, ...)l.ii'           retuovg>logical)
ta.fta.fovgesov[  ' Improvgr va)))keype)))s(h), su]logic    x$gr va.ovges0logic    x$gr va.ov[ov$s(h), suys)
ov$V1t[, shareds.datax$gr va.ov)p = a       some = Fx])
s::splirl))0#' ImproveALt{G){rbinuthor %NN%ata.ftitfs  wi if ski
tcutnwingeobnctif a.framse} ox of  ifs@d =ps(el
#' @param ]
#' 

   x of  if d =asp1,ire  "btks \s= funnta.fdescrip@importd}, gr1 %NN%ngt2rbid}, es} withoas  ns, ignotty asp1i]
#' gt2rbinurdthor  wiw.n-a.framsata.falifrom %NN%,efault -me
#od = functionMe
#od %NN%ata.fanski
rrbind = function (= fucode{RxwSee \link{ wiw.nto s \code{RmentSee \link{ wiw.ntose Ove  if '%NN%',tws, some x,sas.pnstwitardOve  if '%NN%'  
se Me
#od("%NN%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 s(h), subjeN   ;gindh(gr  dx


#'ovges w(gr, windows, ignorex,ty, ore.strand, ...)dt(gr'           retuovg>logical)
ta.fta.fovgesov[  ' Improvgr va)))keype)))s(h), su]logic    x$gr va.ovges0logic    x$gr va.ov[ov$s(h), suys)
ov$V1t[, shareds.datax$gr va.ov)p = a       some = Fx])
s::splirl))0#' ImproveALt{hareds.datax$gr va.ov)pG){rbinuthor %_%ata.ftitfs ::findBiocOve  ifs::l(grl))} ski
tcutn(
{
    are.stic)nta.fdescrip@import Ski
tcutncode::findBiocOve  ifs::l(grl))}ortd}, gr1 st(O + widt1, x + widt10,20), ngths ="+")d}, gr2 st(O + widt1, x + widt15,25), ngths ="-")d}, gr3 st("1:1-15"d}, gr1 %_%ngt2rbi gr1 %_%ngt3rbid}, es} with of windows
#' rl)#' viaks \s(grl))e} ox d wix of  ifrbinurdthor  wis(grl))ata.falifrom %_%,efault -me
#od = functionMe
#od %_%ata.fanski
rrbind = function (= fucode{Rxwct
#'
#' @param }
#'  winnctional argumentswct
#'
#' @param rodequery.gr) ncode{parg'filnrowao' Apply gsub tose Ove  if '%_%',tws, some x,sas.pnstwitardOve  if '%_%'  
se Me
#od("%_%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
     i) ery.gr)), y.t$ogicd = e)))ecrse.g, y.haracl(grl)),.s    ipwidth(ox[ercb)] ,e.s    ipwidth(oy[ercb)] t{G){rrbinuthor  wis(grl))ata.ftitfs  wis(grl))ata.fdescrip@import Mse
 robu' @    f:s(traigrl.d to t thet} Overlaps}
#s::l(grl))ode{GRaRobu' @hNUcommotc dge cas  nsfcl(grl)),.s1,e.s2) is e   ps(eeersectaw
 coto es)
# <de{grgt1's (y andks sata.l(grl))s y and m gr eld wieersectcodecoor m slumns d wigr1 x of  ifs.o io i{ ranges
#' @n' Apply gsub tm }
#'  aseame')o s \code{Rl use ts' Apply gsub tm }
#'  asen use to i{ rangeshen slTRUED      nInfrl)} 
#' @nnlibig    itinRuh d, ighun in oesmrow(r thediffen toblse
 tional argu.cores =D      ndt(grata.frangescores to D      n1. O(ba'workcoifs  cee \cohen slTRUata.fl argumentplied to \winde{pa(g'figes:link{ windows, ignor}d}, es} withe hecksRind(} od.dt
#' @nn#'s c(subsE

hArgicnnteictuTh = function(gr1L(grl))ey = NULL, type = ', data RUE, ...)
{
    grl.iid any')
{
  RU= grl.igreg    ! dfs[sa(by.t.indgnRuh dncand ne\comemde{oaw
fultabRangL(grl))sList(ba'wr \inslumnlows ames(gical)
ta.fta.fate(fops(gr,, data )         on(x {
    grlength(on(x {
   ercbf+r, '-r, '*'tmp = as.da l    values(oud, data )         gp), l(l2grkon([,t
    if (!uniognorex + widthn   " e u), 1,esl[s(hr))
 ][1 eld any')cject r))
 out$

    omcby)]ixgthinfo   s(hinfo ))
      
r]]        som.ind}
#'
gr liefrder$ogical)
           
        strand(gr       #gpby gnore.s    ipwidth(o))
       %Q% (
{
    g1 = rmp = as.da  for (val in levgpby gnore, data )     }SE, length(gpsindows, ignorerop = 'gp, q      )))))
w.names
      , ore.strand, ...), error = functpe)))
}, ion(r))
 ivot a \code{GRebinuthor %*%ata.ftitfs Me{grl.ixjoi2E]
#' .
gatin dasnasekeys (wr, fernges::find\link{ windows, ignor}})nta.fdescrip@import Ski
tcutncode windows, ignorbrows and \cg   } 
#' @examp,   } e
lA)
# <a fieldsa't}
eame')

nd n use tsme{grl.ix)))))rGangTunli= NULL, nnlius
fultcodepiaram ' Apply gsub tm query.gr \wige
#'
ntsn}
#'
 way geser(ek .dt%*%c\codcodGangjoi2 m slumnme{grl.in rows gverlap .
gatin dasnaselumnkeysrl::rnumbE agrl.iusage:l::rnumbxt%*%cy(= fucode{Rxwct
#'
#' @para(= fucode{R@n' Apply gsub to s \s} with of windows
#' coto esram mes')
m cogr li  of the dr2} for all iith of wix} 
#' @exampy'a fieldgjoi2 m slumn{GRansp#' iam nme{grl.irbinurdthor  wfo = functionMe
#od %*%ata.fte data.tfus Rle
#' @ime
#ods se Me
#odata.fanski
rrbind = function (= fudocTretume
#odsata.falifrom %*%,efault -me
#od = funcagrl.sata.ncagrl._gveom %*%.ncagrl._dthfor (val in levels(e)l., list(v      val.vecse Ove  if '%*%',tws, some = ,sas.pnstwitardOve  if '%*%'  
se Me
#od("%*%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 ry.gr windows, ignorex,ty, q      )))))
w.namesx  , s      )))))
w.namesyALt{hareds.datat =od){rRebinuthor %**%ata.ftitfs  windows, ignorb(re  "bts    stranta.fdescrip@import Ski
tcutncode windows, ignorortd}, gr1 %**%ngt2rbid}, es} withnew gtersec coto esram mes')
m cogr li  of the dr2} for all iithgr1 
nd gs(e fieldgjoi2 m slumn{GRansp#' iam me{grl.irbinurdthor  wfo-ski
tcuto iRanctionMe
#od %**%ata.falifrom %**%,efault -me
#od = fuinski
rrbind = function (= fucode{RxwSee \link{ windows, ignor}d}, ecode{RmentSee \link{ windows, ignor}dse Ove  if '%**%',tws, some x,sas.pnstwitardOve  if '%**%'  
se Me
#od("%**%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
     i) ery.gr)), y.t$ogicd = e)))ecrse.g, y.haracry.gr windows, ignorex,ty, q      )))))
w.namesx  , s      )))))
w.namesyAL, ore.strand, ...)dt(gr'Gunkis::split =od){rbinuthor %^^%ata.ftitfs  wiin ski
tcutn(re  "bts    stranta.fdescrip@import Ski
tcutncode wiiportd}, gr1 %^^%ngt2rbid}, es} withill retuvif nod.dtand qu
sp1i]al) i\col.iiuatn
n.')
ist(ba'i asp1[i]i  of the suatnlefrtpnteix of  if d =gt2rbinurdthor  wiin-ski
tcuto iRaalifrom %^^%,efault -me
#od = functionMe
#od %^^%ata.finski
rrbind = function (= fucode{RxwSee \link{ wiin}d}, ecode{RmentSee \link{ wiin}dse Ove  if '%^^%',tws, some x,sas.pnstwitardOve  if '%^^%'  
se Me
#od("%^^%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
     i) ery.gr)), y.t$ogicd = e)))ecrse.g, y.haracs::spligr1i2g  sy, ore.strand, ...)dt(gr'=od){rbinuthor %$$%ata.ftitfs  wi if ski
tcutnwingeobceisting mea opn use ts"x"ade{g rl.ix} and \in)ype =e"ws (re  "bts    stranta.fdescrip@import Ski
tcutncode wi if (usdata if (!)))))
w.names     bid}, gr1 %$$%ngt2rbid}, es} withsp1i]
#' ex  sade{g rl.ix} and \popul dadn}' @igr2rbinurdthor  wiw.n-ceis = functionMe
#od %$$%ata.falifrom %$$%,efault -me
#od = fuinski
rrbind = function (= fucode{RxwSee \link{ wiw.nto s \code{RmentSee \link{ wiw.ntose Ove  if '%$$%',tws, some x,sas.pnstwitardOve  if '%$$%'  
se Me
#od("%$$%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
     i) ery.gr)), y.t$ogicd = e)))ecrse.g, y.haracs::spligr1 if(  sy,  if (!)))))
w.names   , ore.strand, ...)dt(gr'=od){rbinra.s, ignorortd}, Don tmin  ns, ignolibetween m gr@parea oprearr alld tobjs, somesnra1 
nd ra2 (

   {
        wea opnoree..ilcus
m cosanta.
gainstn

   }
#'
,tor of dataixsecrseMngs(diition\coluatn
n.')
ij    j NULL, nnns, ignolij NULL, nj.o io i{   mlied tobpad (G0         )'t}
#'t(ba'(er
subsE, ignotwvectw.nida(t k}
#'
gr li   pad>0n\cogiv h, t}
#o i{paddram 
#' @p nlia
#' ed = o = fand, ..matof t, t}ough'we dastns, ignoty abo \ara1[i]ivsnra2[j] 
nd gs.flip(ra2[j]r
de{GRanges} ora1  of windows
#   w'a fielrearr alld tobse 11{GRanges} ora2  of windows
#   w'a fielrearr alld tobse 12 = fuges} opad AmtuTouwinpad nksi , ignoliby. Lmlier
ospmse
 p tmissiv . D      nospncaubs(0)rbinucode{Rarr1i2d D      ngr = angel arguore.strand, ..Ire.stlrearr alld tobori to t theoperahodata , ignol.=D      ndt(grata.frangesmentrangesbncode{ via ges::find\link{ windows, ignor}}rbinuthor ra.s, ignorort.fte datara.s, ignorey = NULL, tra1))
n2,spad (G0 'urr1i2d grl.iid ore.strand, .=, chunU= grl.igregbp1.gr wf (logicara1)e+spadigregbp2.gr wf (logicara2)e+spadigregfs, n windows, ignorebp1,gbp2, ore.strand, ...), error = function(rigreg.ms (_mndederey = NULL, tjamibp1,gbp2t$ogical)
    l(    ut = magrsa     
     val.ve(GRangesis.null(      on(1ms qun  mp$lenbp1$)
    [ix$s(h), suymibp1$)
     [ix$s(h), suymibp2$)
    [ix$ out = rep(mibp2$)
     [ix$ out = rep(ull(      on(1ms qu.l.gr,
     :unlisction(xon(1ms qu)y(1:s(tmon(1ms qu[,1(mion(1ms qu[,3]p)         tmrsaon(1ms qu[ami          ]mpr (val in##ndm qun nba'occurcoifs 
   r    ' nsaora1 j NULL, nmndedereaediffen tobr    ' nsnksira2 j NULL, rintf('ch)ndeded.l.gr:
     on(1ms qu.l         tmrsamclaf '11','22gr % wil1:s(tmx[,2(mix[,4]ixgtpe(q''mm | mclaf '12','21gr % wil1:s(tmx[,2(mix[,4]ixgtpe(q''mmmpr (val inds.data.l::mclapwp$leats,
     on(1ms qu.l[)ndeded.l]         tmrsamp$lenx[,1(mix[,3]p[!duplif dad(1:s(tmx[,1(mix[,3]p)mi          ]mmmp = a  
                                         c = aate(fowp$len.ms (_mndedertjamibp1,gbp2t, .ms (_mndedertja.revmibp1,gbp2t)                                         c = aon()))))
p[, y')
{
 
igregate(fo.ms (_mndedertjamibp1,gbp2t

         dfs[sa(p[, t$ogical)
    l(    urr1i2d 
     val.ve(GRangesings(di)mp = as.da  for (val in levGRangesMngs(d::secrseMngs(d ut = mara1)#' Improvra2)mix (G0))R    }



#' n()))))
p[, y')
{
 
igreg ol chr)
p[, y')f 'ra1   o, 'ra2   ot

        urr1i2d cal)
    l(roRst(emp[gativ(on([,1(mion([,2()micR            class(ro)=='  {
   rmp = as.data.froRst(ings(diro, n ol=2      =1,gdim chr)=ogicac(),)f 'ra1   o, 'ra2   otout[, shareds.dataro)     }  som.        .froRst(Mngs(d::secrseMngs(d on([,1(mion([,2(mix (G1,gdimsy')f ut = mara1)#' Improvra2)out[, shareds.dataro)     }e{GRebinMergeslrearr alld tos rl)#' viaramby  of windows
#   w'a }
#' rortd}, Don tmin  ns, ignolibetween m gri
rmse
 pparea oprearr alld tobjs, somesn(as!))))dri
ra.fram'fialied to )n+/- pe{grl.nta.
 ..wvectmergebt}oseiitions, igno in oesf nle js, somesn nsnksi eld w,

nd t}
#'in
# = fckncode

   }eld wij NULL, n]al) igesd slumns d wijs, somesn t was!"seen in"wusdataill retuflam nme{g rl.ix} and \prefixramby "seen.by."

nd t}
#'lumnalied tob))))iges(ode"seen.by.ra"

nd t}
nalied tob).framr
de{GRanges} oment' @examples
rl)#' viaks \rearr alld tos ncode{merged = fuges} opad  @panjectiv t  {
      "by"yf thpe{grl.nta.el arguond aill retuflam         ndt(gr'   "by"yf the e
#'
#wumnlseen.bys } whiscshouldscoto esRind(} od.dts d wrb(ra
#'
#wuistill retuflams)

nd hArgicwumngiv h j NULL, nns missil.nta.el arguore.strand, ..s e
#'
#windre.stland, ..(igrli oddsa'and, ..info
mstL, n]vectbli re.senctd palt(your n() risk)o s \s} with of windows
#   w'a f{mergedijs, somesn vqu
me{g rl.ix} and \  "by"yf the l) id slumns d wse

   }eld wtedijs, some was!"seen.bysrbinuthor ra.mergerbinuncagrl.satarbin# gveueryeecoor js, somesd}, gr1 st(O + widt1, x + widt1:10, gr val(g1t uand, ...)rl))cbf+r, '-rt u5))d}, gr2 st(O + widt1, x + widt4e+s1:10, gr val(g1t uand, ...)rl))cbf+r, '-rt u5))d}, ra1 gr:unlissp1,irept1:5,e

   = 2))d}, ra2 gr:unlissp2,irept1:5,e

   = 2))d},d}, ra)h(gra.mergetra1))
n2)d}, w.namesra)   gshowsslumnme{grl.in vqu
l.iiu/ndt(gruflamsd},d}, ra)2h(gra.mergetra1))
n2,spad (G5   gmse
 in caubsmndedks \res   sn nsmse
 mergr) d}, w.namesra)2)d},d}, ra)3h(gra.mergetra1))
n2,si2d grl.ii   ind(} odinstead d sflamsd}, w.namesra)3)ort.fte datara.mergeby = NULL, tas.dapad (G0 'i ...)dt(gr, ore.strand, ...)dt(gr'G      rixgt dfs[!sap     rixgtra
row) >!:
     ra, odfs[sa))cR    nm (!)))))
ra)
         dfs[sa(nmout[, sharenm (!1:s(tm'rar,    else
 ra)ixgtpe(q''m
harenm (!1:s(tm'seen.byr, valugtpe(q'.')(quergica[chr]])nmo==0ut[, shareds.datais.null(  ngth(gra[[1]]
e)l.vecrics::c= spmp$lena    if (!unioings(didt(gr,     xgt ,-1, dou t un      [chr]])nmo,gdim chr)xgt dfs[
{
  Rnmou , al.ames= dat
2))
     ! 2d 
     valal.ames= da[ Rnm[1]]= 1Tr = grl.  for (val inal.ames= da[ Rnm[1]]= 1   else
 \code(quergica[chr]])ra)>1t$ogical)
    l(ct(nain ns2  else
 ra)t$ogicd = NULL; V1 = NULuh dfrixgtra
[i]]dfs[[x]]
         else
 uh dfri)            x])
{r (val in levels(l.ix', uh dfri) spmp$lena    if (!unioings(didt(gr,     xgt ,-1, duh dfri) un      [chr]])nmo,gdim chr)xgt dfs[
{
  Rnmou , al.amesuh dfri))                 ovfs, nra.s, ignor.rl.ixuh dfridapad (Gpad, ore.strand, ...) 
        stranbject.rle[[chr]] L   !itrand(gr       #gg <e)l.al.amesuh dfri)[[nm[i]]]= 1Tr = grl.unlita.fta.f  for (val in levels(e)l.al.amesuh dfri)[[nm[i]]]= 1   else
 uh dfri)nbject.rle[[chr]] L   !itrand(gr       #gg <r2))
                 L   !mcla dfsa(ovfs)t)                         al.ames= da[ Rnm[i]][ovfs[,1(]= 1Tr = grl.unlita.fta.f} grl.unlita.fta.f  for (val in levels({
                    al.ames= da[ Rnm[i]]bjeNA
))
                 L   !mcla dfsa(ovfs)t)                         al.ames= da[ Rnm[i]][ovfs[,1(]= 1ovfs[,1( grl.unlita.fta.f} 
                L   !mcla dfsa(ovfs)t) indw l) iaw
 new r all i chualready )#' vian nsrl.ixwe wvectmd =] ifor (val in levels(e)l.nfs, nl(grl)),   else
 uh dfri),1ovfs[,2]mp = as.data.fta.f  for (val in levels(e)l.nfs, n   else
 uh dfri)nbject.rle[[chr]] L   [chr]])nfs)            x])
els({
                    al.1h(g.ix, nm\code                    al.2h(g.ix, nmuh dfri)n))
                 L   i .           tmp = hits[, lial.2[ Rnm[1:(i   ]ys)
NA
))
                   for (val in levels(e)l., lial.2[ Rnm[1:(i   ]ys)
dt(gra                    al.ames= day')
{
 
 (val in levels(e)l.al.amesuh dfri)y')
{
 
 (val in levels(e)l.ngth(gpslp$lenol.ixuh dfri[nfs])a                    al.ames= day')rwp$lenal.1,ial.2[njamic) grl.unlita.fta.f} grl.unlita.f} liic## by is n}

#' Apply \ode{gsub} tDeduplif daslrearr alld tos rl)#' viaramby  of windows
#   w'a }
#' rortd}, Don tmin  ns, ignolibetween m gri
rmse
 pparea oprearr alld tobjs, somesn(as!))))dri
ra.fram'fialied to )n+/- pe{grl.nta.
 ..wvectmergebt}oseiitions, igno in oesf nle js, somesn nsnksi eld w,

nd t}
#'in
# = fckncode

   }eld wij NULL, n]al) igesd slumns d wijs, somesn t was!"seen in"wusdataill retuflam nme{g rl.ix} and \prefixramby "seen.by."

nd t}
#'lumnalied tob))))iges(ode"seen.by.ra"

nd t}
nalied tob).framr
de{GRaninski
rXiaoto @pYaoe{GRangeList} o' @examples
rl)#' viaks \rearr alld tos ncode{merged = fuges} opad  @panjectiv t  {
      "by"yf thpe{grl.nta.el arguore.strand, ..s e
#'
#windre.stland, ..(igrli oddsa'and, ..info
mstL, n]vectbli re.senctd palt(your n() risk)o s \s} with of windows
#   w'a f{mergedijs, somesn vqu
me{g rl.ix} and \  "by"yf the l) id slumns d wse

   }eld wtedijs, some was!"seen.bysrbinuthornra.deduprbinuncagrl.satarbinfte datara.dedup (!ws, some = FALpe{=500d ore.strand, .=, chu).igregindTODO: deduplif dan t selfigreg    ! d = FAL"ndows
#   w")pnstop("I d wimu' @beo' @examples!"t

        uny(GRangesNROWS     !=2)pnstop("E
   GRangesimu' @beoand qu
2!"t

         else
     ==0 |  else
     ==1)cs::spligrlt

         else
     >1t{ grl.unligx.m col)

   )
        p = as.data.fra.s, ignor.= FAL= FALpe{=pad, ore.strand, ...) 
        stra)[ra1   !=ra2   cR            ion(xgx.m coo==0u{r (val in levGRangesgrlt
liic## by  som.        .fy(dfsup.fs, nuniquetrowMaxsll(ings(digx.m coo))r (val in levGRangesgrl[-sup.fs]) liic## by is n}
sub} tSh  x   j NULL, ctaw
 Deduplif dadortd}, Don tmin  ns, ignolibetween m gri
rmse
 pparea oprearr alld tobjs, somesn(as!))))dri
ra.fram'fialied to )n+/- pe{grl.nta.
 ..wvectmergebt}oseiitions, igno in oesf nle js, somesn nsnksi eld w,

nd t}
#'in
# = fckncode

   }eld wij NULL, n]al) igesd slumns d wijs, somesn t was!"seen in"wusdataill retuflam nme{g rl.ix} and \prefixramby "seen.by."

nd t}
#'lumnalied tob))))iges(ode"seen.by.ra"

nd t}
nalied tob).framr
de{GRaninski
rXiaoto @pYaoe{GRangeList} o' @examples
rl)#' viaks \rearr alld tos ncode{merged = fuges} opad  @panjectiv t  {
      "by"yf thpe{grl.nta.el arguore.strand, ..s e
#'
#windre.stland, ..(igrli oddsa'and, ..info
mstL, n]vectbli re.senctd palt(your n() risk)o s \s} with of windows
#   w'a f{mergedijs, somesn vqu
me{g rl.ix} and \  "by"yf the l) id slumns d wse

   }eld wtedijs, some was!"seen.bysrbinuthornra.duplif dadortnuncagrl.satarbinfte datara.duplif dad (!ws, some = FALpe{=500d ore.strand, .=, chu).igregindTODO: deduplif dan t selfigreg    ! d = FAL"ndows
#   w")pnstop("I d wimu' @beo' @examples!"t

        uny(GRangesNROWS     !=2)pnstop("E
   GRangesimu' @beoand qu
2!"t

         else
     ==0)cs::spliill ret(0)t

         else
     ==1)cs::splidt(gr'G
         else
     >1t{ grl.unligx.m col)

   )
        p = as.data.fra.s, ignor.= FAL= FALpe{=pad, ore.strand, ...) 
        stra)[ra1   !=ra2   cR            ion(xgx.m coo==0u{r (val in levGRangesrl))
    out[tmp[,1]lelse expanded  som.        .fy(dfsup.fs, nuniquetrowMaxsll(ings(digx.m coo))r (val in levGRangesseq_alo @,1]le % wilsup.fs) liic## by is n}
sub}# } tCalc
m cogr lidistwiceccoderearr alld tos rl)#' viaramby  of windows
#   w'a }
#' ror# } b}# } ts} withi[tmp[,1]lemby i[tmp[,1]lem
    if(ings(did sm cogr lidistwicelibetweenb}# } tjs, somes,t
 n   es)amby lumnal.amty asp1dist m slumn{GRansp#' iam breakpo  {ror# } b}# } tninski
rXiaoto @pYaoe{# } tnngeList} o' @examples
rl)#' viaks \rearr alld tos ncode{merged =# } tnngeLisore.strand, ..s e
#'
#windre.stland, ..(igrli oddsa'and, ..info
mstL, n]vectbli re.senctd palt(your n() risk)o # } b}# } tns} with of windows
#   w'a f{mergedijs, somesn vqu
me{g rl.ix} and \  "by"yf the l) id slumns d wse

   }eld wtedijs, some was!"seen.bysrb# } tnthornra.d  wo # } b}# } tnte data.#nra.d  w (!ws, some = FALore.strand, .=, chu).i##      wl.srw (!so.idocl)i##     pv. wl.srw (! wl.pivoidocl.srw)i##     bp1.grpv. wl.srw[[1]]
##     bp2.grpv. wl.srw[[2]]

##          
        straseidth(obpsay')"*"

##     d  w1.gr w.d  webp1,gore.strand, ...) 
        stran##     d  w2.gr w.d  webp2, ore.strand, ...) 
        stranb##     s::spliigicae  w1, d  w2)an## sub} tSigrlify gtersec ba'coby = dataiect cpal
#' @param adjacvia r     iitionshaw
 angiv h "} and"nal.amiges(adjacvia == adjacvia  <slumns put efault iodata  
ql{GRanges} objetakl iithgr ode wltable Returf
whicquery.gr) s:mcao,c{GRansp#' iam winal.amtf
whicy asp1h of wi[
{
 ]to s \code{Rvuer::find[
{
 ]to s \code{Rincludei if s:mcao ill ret,n]vectincluden nsrl.hgr ing meaf
whicy ae
#' @mndedks \re{GR
# <as d wigr1h of wi[Tr =]to s \code{R:unli Sunli nksi eld wiin oe of windows
#   w'a:unli by  of wi"} and"}1h of wi[      } = fuges} opad Pe{ tersec ba'uh dnamtuToubef.stlhodatamerge. [1(mie l) imergeslcotoiguous sect cpal
#' @param tersecrGanges} withSigrlifiediefault i vqu
"} and"npopul dadn vqu
uniqueba'cotoiguous ing me = function(gr1Ligrlify (!ws, some = ,s} andx=  = FAL if (! = FALincludei if grl.iid :unli .)dt(gr, pad (G1  .igregate(foll(ill ret(sup)#' sWaf datsvgr va(Overlaps}
#' @np  of the (tersecit [-t[tmp[,1] ]), tersecit [-1]+pad),ire olve.empty (!'hen sn   '))    &r (val in levels(e)l.,s(hr))
    [-t[tmp[,1] ]) == s(hr))
    [-1]) &seidth(ooc[-t[tmp[,1] ]) == sidth(ooc[-1 el
igregate(foll(vif no(c)0#'cum, m(!p[, tt
2))
     !    rout} and.t$ogicgregate(fo1:s(tmon(,g.ix, nm,   ,el and t
2))
     !    rout.ix.t$ogicgregate(fo1:s(tmon(,g.ixt
2))
 ol)
rltmon(t
2))
 lfs, nunigica,
        else
 r$lues(ou)         tmrsarl))x,to$lues(ou[x]mmmp = asn.ry.gr:unlisa) ery.gr)), s(hr))
    t)#' fs) liicst.ry.gr:unlisect.idoc)#' fs) liicen.ry.gr:unlis   ioc)#' fs) liicstr.ry.gr:unlisa) ery.gr)), sidth(ooc))#' fs)  liicst.ry.mi2E  :
     st.ry  mi2) liicen.ry.max   :
     en.ry  m  )SE, length(g(seqlen,s
     sn.ry         tmrsax[1 e, x + widtht.ry.mi2,cen.ry.max),r (val in levels(e)ngths = se
     str.ry         tmrsax[1 e, gthinfo   s(hinfo 1]   igregfs, nmnded.   else
 \cod#' fs)  liicL   i cludei if 
     valal.ames= dah(g.ix, nm,   jamic  liicL   :unli(r  l.unligica!    rout} and.t$ogicgreg, length(g(verlaps}
#' @n:unlisol.ix.ix, nm,   jamil and t
          for (val in levngth(g(seqlen   w \code(querApply \ode{gsubse Ove  if '%Q%',tws, some x,sas.pnstwitardOve  if '%Q%'  
rbinuthor %Q%ata.ftitfs 
#' @nr    c ba'
    ram an nct#' some  oer    c me{grl.irbinudescrip@importd}, gr %Q% 
#' @nr hecksReratle}se ery asp1iitionmndedereme{g rl.ixstwtangesiin)ype =rbid}, es} withsubse 1y aspiitionmndedereame')o s \rdthor  wiame')o s \docTretume
#odsata.falifrom %Q%,efault -me
#od = fucode{Rxwct
#'
#' @paramwinms qunrgainstnas
#' @n' Apply gsub to s \code{R@n' Apply gsub tm vqu
me{grl.ixncode{
#' iedrbinate data.tfuinski
rrbind = function (se Me
#od("%Q%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 
#' if th_oa 3       stitusuby.harac## s' ious R voodoo gymnasticssas sectIser(ek  esgrl  hack)
# a gesreml
# ghos{roliicenvh(g
 (c## creftecenvirond tobntioncombin  nlumncallram mnvh vqu
wumngtersec envr (val inc( lell(((((((((ll(i  w 1:n to (!unio2)a,ll(((((((((ll(i  w a    if (!uniox.t$ogicgregt u'environd to')(quer1:n to env env))))ecr to (!uniopply(dfs, ntryCnded.e if(
#' if th_oa 3epenv)eperror (!ws, some e) is.null(       dfs[sa(ix t$ogical)
    l(
#' if th_oa 3       stitusuby.harac                                    c = a               Ls, n vqu(Overlaps}
#' @na    if (!uniox.,(e if(
#' if th_oa 3.t$ogicgregLs, ne if(
#' if th_oa 3epOverlaps}
#' @na    if (!uniox.) is n}

#' Apply \ [ix]=od){rbinuthor %^%ata.ftitfs  wiin ski
tcutnta.fdescrip@import Ski
tcutncode wiipegectitardialied to )ortd}, gr1 %^%ngt2rbid}, es} withill retuvif nod.dtand qu
sp1i]al) i\col.iiuatn
n.')
ist(ba'i asp1[i]i  of the suatnlefrtpnteix of  if d =gt2n(
{
    are.stic)nta.frdthor  wiin-ski
tcuto iRacode{Rxwct
#'
#' @param }
#' ata.fl argumentp to be supplied to \nco wiin angenction( s \docTretume
#odsata.falifrom %^%,efault -me
#od = fucode{RxwSee \link{ wiin}d}, ecode{RmentSee \link{ wiin}dubse Ove  if '%^%',tws, some x,sas.pnstwitardOve  if '%^%'  
se Me
#od("%^%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
     i) ery.gr)), y.t$ogicd = e)))ecrse.g, y.haracs::spligr1i2g  syLt{G){rrbinuthor %$%ata.ftitfs  wi if ski
tcutnwingeobceisting mea opn use ts"x"ade{g rl.ix} and \in)ype =e"ws (
{
    are.stic)nta.fdescrip@import Ski
tcutncode wi if (usdata if (!)))))
w.names     bid}, gr1 %$%ngt2rbid}, es} withsp1i]
#' ex  sade{g rl.ix} and \popul dadn}' @igr2rbinurdthor  wiw.n-ski
tcuto iRadocTretume
#odsata.fcode{Rxwct
#'
#' @param }
#' ata.falifrom %$%,efault -me
#od = functionMe
#od %$% = fuinski
rrbind = function (se Ove  if '%$%',tws, some x,sas.pnstwitardOve  if '%$%'  
se Me
#od("%$%" ',oreaplye=x.gr"ndows
#".,tws, some x,sy  r2))
 s::spligr1 if(  sy,  if (!)))))
w.names   '=od){rbinecrse.g,lrbid}, quickncs, some winparsee of windows
#   w'a}' @iquery.gr) vif nodIGV / UCSCnstyltlanddatscy aeo
msthsp1;gr2;gr3 s e   

   gr
ospy aeo
msthchr:ect.i-   [+/-]rbid}, uthor ecrse.g,lrbi.fcode{Rxwiquery.gr) vif nodrl)#' viaks \ao' @examples
]
#' UCSCnstyltl.
gatin dasn(chr:ect.i-   [+-])drl)#' viaks \ao[noree.] Geersectand a";"ugtpaeryors'wr \ins

   xtanpy axugtpaeryks \ind(vidaul 

   {
A    rbinucode{R:ths(gr))
  !))))dr  {
    vif nodrl)#' viaks \gverle (hg_ values(oudemby        ) = fuinski
rrbind = function (= function(ecrse.g,l (!ws, some x, sths(gr))
   hg_ values(oude  .igregnm (!)))))
s) liicate(foand:unlisx, '[;\\,]') liicate.u, nunigicaon(t
liicate.u, ngn u('\\,r, ''mion(1ut
liicate.i...)rl))   else
 un(t,r:
     on(out[tmp[)) liicstr, ngn u('.*([\\+\\-])$','\\1'mion(1ut
liic:un(foand:unlison(1u, '[\\:\\-\\−\\+]ly(1e,l (!Tt

        uny(Ls,s) s
     :unout[tmp[)==2t)       :un[ix].gr,
     row) >ix)         tmrsa:un[[x]][c)  2,2)]t

        uny(Ls,s) s
     :unout[tmp[)!=3 t$ogica      l)
           dfs[sa( values(ou.t$ogicgreg, lestop('Ne\comem   es)\gverle btuThari odmemd pachromocoor mnba'cogatin dalanddatsrmp = as.da:un[ix].grand:unlisgUtil @ng
. 
 ramsgUtil @nsi2grk values(ou.[s
     :un[ix]         tmrsax[[1]])]ixmb .)d), '[\\:\\-\\+]ly(1e,l (!Tt
ta.f} 
        uny(Ls,s) !str,% wilcbf+r, '-rttmp = as.da tr[ix].gr'*'p = adf spmp$lena    if (!unioings(diunigica:un) un      3ctpe   xgtTt uanddatsAsFengths .)d), andm
haren))))
df y')f 'chrout$

   ' u'endout$

    o)p = adf$

   (foll(
    if df$

   )p = adf$es = sll(
    if df$e .       n()))))
df y')
{
 
igregry.gr Util @ns(l2grkdf, sths(gr))
    values(ou)[ercb)]igregrylh(g(verlaps}
#' @n:unlisry  ate.i.m
haren))))
1]lem(!)m
 levGRangesgrlt
{GRebinuthor ancki
lif ata.ftitfs ancki
lif ata.fdescrip@importd}, "lif s"aiect
#' iesa fielre  "bt
gess use tsin).
gatin dasncorreare'wr \ins"padsrbini.e. d wset}
eame'il iitgess use t-cviarap .
gatin das,i]al) i\coahnew gverle  fiellabel "Ancki
"         )ode{GRaRe  "bts    stra opn use ts(i.e. iopn use ts   stragr
osp"-" t}
#']vectlif aiect
#' iesagesereigef p.dts ata.itgespositiv ts use t-cviarap .
gatin das). Keeps = fckn opn use tsstra
#' @nndanot lagr) de
#'voluLL, nnf ne\cobe.o io i{ ranges
#' @niefault icorre]vectblilift\coartuThReratle}
#' ata.fl argun use tsefault iartuThR]al) it}
eame'il i]vectblilift\cata.fl arguwdowsw  @panjectiv t  {
     :mcao   "by"yf thh  xfao artuThR

   n use tswinga
#'
#
#' @nn#of  ifs@winlif a        n1e9)rbinucode{Rby iquery.gr) vif nod  "by"yf thp to be sup   umspege.g. s
grl.ii.miartuThR]al) itesreanddcons, ignosn(vian windows, ignor)a        nis.nulbinucode{R:ththor Cuery.gr) s "by"yf tht}
ethor d slumn eld wi:thueicecartuThR]al) itesancki
a        n"Ancki
")o s \code{Rincludei if meaill retuflam s e
#'
#windncludening meaf' @iame')

nd n use ts        nl.ii  = fuinski
rrbind = function (= function(ancki
lif ey = NULL, type = ', data RUwdowsw =n1e9d any')
{
  R:ththor =n"Ancki
",Rincludei if meagrl.ii  .igr    ul(
    if t[tmp[,
      *ul(
    if t[tmp[,))
      ==0ut[, sds.datais.null(ovges windows, ignorerop = ', data +wdowswctpe)))
})
       else
 ov ==0ut[, sds.datais.null(novgesrop =[ov$s(h), suys%-% (
{t.id, data [ov$ out = rep(u + rtuThvgr va(rop =[ov$s(h), suy)/2t)   w.namesnov) spmp$lenw.namesnov), al.ames=v))   l)
flip..) f  fo(width(o))
     [ov$ out = rep( g1 =+r, 1, -1pplyate(f t(
     mp$len
{t.idnov)*flip" e udnov)*flip), 1,esion  
  ,2]h(g(seqlen,sththor,  x + widton([,1(mion([,2())   w.namesode{$))
    ))
   ov$ out = rep   w.namesode{$s(h), subjeov$s(h), su
icL   i cludei ifame)   {
e)l.vecrics::c= spmp$lenvecrics::c=,t
    if (!uniow.names
      [ov$s(h), su,               )
e)l.vecrics::c= spmp$lenvecrics::c=,t
    if (!uniow.names))
      [ov$ out = rep, ,             )
e)}

 ivot a \code{GRebinecrse.g,rbid}, quickncs, some winparseegr
}' @iquery.gr) vif nodIGV / UCSCnstyltlanddatscy aeo
msthsp1;gr2;gr3 so e   

   gr
ospy aeo
msthchr:ect.i-   [+/-]rbid}, uthor ecrse.g,ata.fl argumentplied to \winecrse.g,l i.e. query.gr) snddatscd =UCSCnstyltl.hr:ect.i-   [+-]rbinate data.tfuinski
rrbind = function (ecrse.g,by = NULL, tas.'G      rvot a unigicaecrse.g,ltas.'){gsub} tBreaksefault iatngiv h breakpo  {r.itgesdisjoi2thsp
de{GRaninski
rXiaoto @pYaoe{Ga.tfus Rle
g(verlaps}
#' o io i{ rangesbosnct
#'
#' @param f gr val1,elocry.gr \d slumnbp;{   mny GRangesigr vao i{lmlier
wuist1,gbo \abtuTharyi]vectbli
#'de{gr)dr  d(viduetubreakpo  {rori{ ranges
#' @nasdisjoi2thct
#'
#' @param }
#'  winblibrokenrbid}, es} with of windows
#' disjoi2th }
#'  atnlefrtperatlhor and qu
aseame'),d},  fieldgme{grl.ix   umth of wiqid}Rind(}ryks \ind wiindex s e   new s(lngesiieaf' @atarbinfteagrl.satarbi = function(gr1breakrey = NULL, tbos=
{
  Rame')=
{
 ).igregindALERT:ibig quews
!\ind wirangeegr) shuffled!
igregind   bosn chuprovidencts} withoack-= fc)drdisjoi2 wr, ferll(       dfs[sa(bpsa cal)
    l(rvot a 
          }  som.        .find}(ba'w}
#'bosn\cogiv h doxwe caw
 abRangworre
#' @nnll)
           dfs[sa(
              .fy(df)))sage("Tryf thchromocoors 1-22

nd X, Y."t$ogicgreg, le
#' @n  hg_ values(oudedfs[[x]]
         dfs[sa(
              .fy(dfy(df)))sage("D      nBSgverle  chuctuThout[t's uerdof wts ."t$ogicgreg, le  l(

    ystemindle("extrl.i",harac                             "hg19.regulmlChr.chrom.sizes", packageby " Util "t$ogicgreg, le  l( l   read.dnctm(cs,iheader=, chunUsep="\t"t$ogicgreg, le  l( l   setN))))
sl$V2,esl$V1t$ogicgreg, le  l(
#' @n  .s    ipwidth(o)i2grk l.t$ogicgreg, le} liic## by        .findprl)#oc))seame')o  l.unligica!  Disjoi2t(
              .fy(dfwaf dat("Q#' @nefault i chudisjoi2t."t$ogicgreg, le
#' @Djn  disjoi2 
          greg, le
#' @Dj$qsubje
#' @Djn%N%n
#' @nind}(ba'rvoa <slumne
#' @occureice
            al.ames
#' @Dj= spmp$lenvecrics
#' @Dj=,harac                                
   )
        w.names
      [
#' @Dj$qsu]t$ogicgreg, le
#' @n  
#' @Dje expanded  som.        .fy(dfgica"qsu",% wilcol chr)
w.names
               .fy(dfy(dfwaf dat("'qsu'lcol\in)ype =es, iwritten."t$ogicgreg, le}$ogicgreg, le
#' @$qsubjeseq_alo @,
          gregy        .findprl)#oc))sebos       .findhaviam me{gx} and ?sreml
# lumm!       .fborey bor[ercb)]i       .findreml
# ludatscyutde{gr opref
ta.fta.foo. values(o, n ow) >
{t.idbpsa<1 | e udbpsa> values(oudbpsa[a) ery.gr)), s(hr))
  bpsa ])l)
    l(    ut = maoo. values(o)           .fy(dfwaf dat("Srle breakpo  {r.Rang opchr and qus. Reml
dat."t$ogicgreg, leborey bor[-oo. values(o]     gregy        .f    uny(!    routr))
  bpsa           .fy(dfwaf dat("Reml
dat  n(en))))
}' @ibps."t$ogicgreg, ler))
  bpsay')
{
 
 (val iny        .findhaviam and, ..info?sreml
# it!       .f    uny(eidth(obpsa!="*")         .fy(dfwaf dat("Srle breakpo  {r.have and, ..info. Forcecwin'*'."t$ogicgreg, leborey .s    ipwidth(obpsa
 (val iny        .find olve lureec dge cas         .f    uny(w.0,s) vgr va(bpsa<1))         .fy(dfwaf dat("Srle breakpo  {igr va==0."t$ogicgreg, leindrightabtuThesmrow(r .
ga$ogicgreg, leind
nd t}
re' i c njectiv tgr valGRia
#' ed ogicgreg, lebor
row) >w.0)]ey .s   t.idbps
row) >w.0)])s%-% 1
greg, le}$ogicgreg    uny(w.2,s) vgr va(bpsa==2t)         .fy(dfwaf dat("Srle breakpo  {igr va==2."t$ogicgreg, leinduh dnis se h asebreakpo  {ibyxsecn datam grbas         .f, lebor
row) >w.2)]ey .s   t.idbps
row) >w.2)]) liic## by is ngreg    uny(w.l,s) vgr va(bpsa>2t)         .fy(dfind ole  chua po  {?  withitilnrowaopo  {       .fy(dfwaf dat("Srle breakpo  {igr va>1."t$ogicgreg, lerborey .s e udbps
row) >w.l)]t$ogicgreg, lelborey .s   t.idbps
row) >w.l)]t$ogicgreg, le  t.idlbpsay')pmax(  t.idlbpsa-1,g1t$ogicgreg, leborey cdbps
row) >!w.l)], andrde{G(cdlbps,erborelse expanded
       .fbor$inQ#' @n  bore%^%name')o  l.unligicauny(bor$inQ#' @==F)         .fy(dfwaf dat("Srle breakpo  {i chuwr \ins
#' @nr    c."t$ogicgregy        .findlabel stra nba'co'de{gr breakpo  {r. chualready atperatbtuTharyi.dt
#' @       .fbor$innern  bor$inQ#' @       .fbor$inner
row) >bore%^%n.s   t.id
      | bore%^%n.s e ud
      ]=Fr (val in##ndmybe  c innernbp atpa 3ept}
#' c nj\comem)#oc)ed ogicgregL   !mny(bor$inner)u{r (val in levGRanges
          gregy       .fborInnern  bor %Q% (inner==T)r (val in##ndmpiame')

nd innernbreakpo  {rogreg, le
bMapges windows, ignorerop = 'borInner)rintf('ch)n fedQbjeseq_alo @,
     ,% wil
bMap$s(h), su
iceg, leindraw .
gas@hNUconanducwieersectc' @aogicgregatefaultn  d)
        qsu2.gr
bMap$s(h), su,harac                            t.i#' @i=   t.id
    [
bMap$s(h), su]=,harac                          breakAti=   t.idborInner[
bMap$ out = rep(u,harac                          upTo   e ud
    [
bMap$s(h), su]=t$ogicgregateCoor (!atefault[er.(pos=so.iduniquetc(  t.i#' @, breakAt, upTo))eld an=qsu2]i       .findconanducwinew r all t[, sharenewfaultn  ateCoor[er.(  t.i=pos[-row) .max(pos)],harac                           e u=pos[-row) .mi2 pos)]ld an=qsu2]i[, sharenewfault[er":="(chr(foll(vif no(s(hr))
  
     [qsu2]u,harac                    ngths = sll(vif no(sidth(o
     [qsu2]u)]i[, sharenewfault$

   (fonewfault[er f  fo(wit.i==mi2 

   ), hn   " hn   +1)]i       .findputnwige
#'
#wumn)n fed

nd brokenr[, sharenewGrh(g(seqlen,newfault, gthinfo   s(hinfo 
      
     valal.amesnewGrah(g.ix, nm
     [newGr$qsu2mi      =F]findprlser
# lum\ind wime{gcol       .find vqu
wumn  {aubs chu)n fed
p   (.dt
#' @       .f eld wi(!so.idcsnewGr Rame')[!)n fedQ]=t$ogicgregind%Q% (gativ( = functs(hr))
 " hn   =t$ogicgregindbrowser(ut[, shareds.d